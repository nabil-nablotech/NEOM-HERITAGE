-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `field_codes`
--

DROP TABLE IF EXISTS `field_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_codes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `field_codes_created_by_id_fk` (`created_by_id`),
  KEY `field_codes_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `field_codes_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `field_codes_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_codes`
--

LOCK TABLES `field_codes` WRITE;
/*!40000 ALTER TABLE `field_codes` DISABLE KEYS */;
INSERT INTO `field_codes` VALUES (1,'siteType','2022-10-12 22:08:50.558000','2022-10-12 22:08:50.558000',1,1),(2,'period','2022-10-12 22:09:09.787000','2022-10-12 22:09:09.787000',1,1),(3,'researchValue','2022-10-13 14:55:57.825000','2022-10-13 14:55:57.825000',1,1),(4,'tourismValue','2022-10-13 14:56:17.101000','2022-10-13 14:56:17.101000',1,1),(5,'stateOfConservation','2022-10-13 14:56:36.714000','2022-10-13 14:56:36.714000',1,1),(6,'risk','2022-10-13 14:56:53.535000','2022-10-13 14:56:53.535000',1,1),(7,'recommendation','2022-10-13 17:00:49.875000','2022-10-13 17:00:49.875000',1,1),(8,'artifacts','2022-10-18 17:11:20.059000','2022-10-18 17:11:20.059000',1,1),(9,'assessmentType','2022-10-18 19:42:30.289000','2022-10-18 19:42:30.289000',1,1),(10,'actionType','2022-10-27 13:26:04.359000','2022-10-27 13:26:04.359000',1,1);
/*!40000 ALTER TABLE `field_codes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-10  9:39:36
