-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_blocks_common_fields`
--

DROP TABLE IF EXISTS `components_blocks_common_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_blocks_common_fields` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `file_size` varchar(255) DEFAULT NULL,
  `storage` varchar(255) DEFAULT NULL,
  `make` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `depth` varchar(255) DEFAULT NULL,
  `dimension` varchar(255) DEFAULT NULL,
  `created` date DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_blocks_common_fields`
--

LOCK TABLES `components_blocks_common_fields` WRITE;
/*!40000 ALTER TABLE `components_blocks_common_fields` DISABLE KEYS */;
INSERT INTO `components_blocks_common_fields` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'190664','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(3,'151913','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(4,'135752','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(5,'186129','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-07 00:00:00.000000'),(6,'169950','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(7,'164777','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(8,'161335','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-07 00:00:00.000000'),(9,'164021','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(10,'165190','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(11,'170903','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(12,'201425','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-07 00:00:00.000000'),(13,'203099','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-07 00:00:00.000000'),(14,'4808723','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(15,'4976648','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(16,'5039358','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(17,'4582205','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(18,'4468896','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(19,'4634729','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(20,'4554918','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(21,'5462273','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(22,'5384137','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(23,'4912503','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(24,'4836676','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(25,'3694273','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(26,'3828390','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(27,'4859629','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(28,'4801970','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(29,'4988255','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(30,'4893992','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(31,'4863027','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(32,'4784437','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(33,'4733070','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(34,'4653256','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(35,'4845118','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(36,'4763740','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(37,'4352719','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(38,'4294599','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(39,'3675029','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(40,'3505202','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(41,'4522142','Embedded',NULL,NULL,'72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(42,'4426420','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(43,'4811292','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(44,'4908456','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(45,'4878000','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(46,'3400427','Embedded','Apple','Apple','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(47,'3579762','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(48,'4034030','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(49,'4151198','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(50,'4785285','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(51,'4634211','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(52,'2921443','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(53,'2733992','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(54,'11779096','Embedded',NULL,NULL,'72 x 72 dpi','2266 x 1488','2022-07-11','2022-09-13 00:00:00.000000'),(55,'6627002','Embedded','Apple','iPad','72 x 72 dpi','4032 x 3024','2022-07-07','2022-09-13 00:00:00.000000'),(56,'2127487','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-07','2022-09-13 00:00:00.000000'),(57,'2140491','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-07','2022-09-13 00:00:00.000000'),(58,'4250830','Embedded','Apple','iPad','72 x 72 dpi','4032 x 3024','2022-07-07','2022-09-13 00:00:00.000000'),(59,'3986210','Embedded','Apple','iPad','72 x 72 dpi','4032 x 3024','2022-07-07','2022-09-13 00:00:00.000000'),(60,'3918001','Embedded','Apple','iPad','72 x 72 dpi','4032 x 3024','2022-07-07','2022-09-13 00:00:00.000000'),(61,'8406757','Embedded','Apple','iPad','72 x 72 dpi','4032 x 3024','2022-07-06','2022-09-13 00:00:00.000000'),(62,'3608740','Embedded','Apple','iPad','72 x 72 dpi','4032 x 3024','2022-07-04','2022-09-07 00:00:00.000000'),(63,'3573025','Embedded','Apple','iPad','72 x 72 dpi','4032 x 3024','2022-07-04','2022-09-07 00:00:00.000000'),(64,'4767882','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-08','2022-09-13 00:00:00.000000'),(65,'4523777','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-08','2022-09-13 00:00:00.000000'),(66,'3907836','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-08','2022-09-13 00:00:00.000000'),(67,'4201934','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448',NULL,'2022-09-13 00:00:00.000000'),(68,'2007322','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-07','2022-09-13 00:00:00.000000'),(69,'5828542','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-07','2022-09-13 00:00:00.000000'),(70,'4417121','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-07','2022-09-13 00:00:00.000000'),(71,'4770741','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-07','2022-09-13 00:00:00.000000');
/*!40000 ALTER TABLE `components_blocks_common_fields` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 17:10:26
