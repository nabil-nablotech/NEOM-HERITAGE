-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `files_related_morphs`
--

DROP TABLE IF EXISTS `files_related_morphs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files_related_morphs` (
  `file_id` int unsigned DEFAULT NULL,
  `related_id` int unsigned DEFAULT NULL,
  `related_type` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `order` int unsigned DEFAULT NULL,
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `files_related_morphs_fk` (`file_id`),
  CONSTRAINT `files_related_morphs_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files_related_morphs`
--

LOCK TABLES `files_related_morphs` WRITE;
/*!40000 ALTER TABLE `files_related_morphs` DISABLE KEYS */;
INSERT INTO `files_related_morphs` VALUES (3,1,'api::login.login','image',1,1),(2,2,'shared.logo','image',1,2),(2,1,'shared.logo','image',1,3),(3,1,'api::login.login','backgroundImage',1,4),(144,1,'api::media.media','object',1,5),(98,2,'api::media.media','object',1,6),(131,3,'api::media.media','object',1,7),(101,4,'api::media.media','object',1,8),(108,5,'api::media.media','object',1,9),(128,7,'api::media.media','object',1,10),(103,8,'api::media.media','object',1,11),(135,9,'api::media.media','object',1,12),(134,10,'api::media.media','object',1,13),(127,6,'api::media.media','object',1,14),(95,11,'api::media.media','object',1,15),(141,12,'api::media.media','object',1,16),(20,13,'api::media.media','object',1,17),(37,14,'api::media.media','object',1,18),(24,15,'api::media.media','object',1,19),(47,16,'api::media.media','object',1,20),(35,17,'api::media.media','object',1,21),(30,18,'api::media.media','object',1,22),(42,19,'api::media.media','object',1,23),(49,20,'api::media.media','object',1,24),(43,21,'api::media.media','object',1,25),(32,24,'api::media.media','object',1,26),(45,23,'api::media.media','object',1,27),(19,22,'api::media.media','object',1,28),(11,25,'api::media.media','object',1,29),(28,26,'api::media.media','object',1,30),(21,27,'api::media.media','object',1,31),(26,30,'api::media.media','object',1,32),(46,29,'api::media.media','object',1,33),(44,28,'api::media.media','object',1,34),(27,31,'api::media.media','object',1,35),(16,32,'api::media.media','object',1,36),(15,33,'api::media.media','object',1,37),(36,34,'api::media.media','object',1,38),(23,35,'api::media.media','object',1,39),(18,36,'api::media.media','object',1,40),(39,37,'api::media.media','object',1,41),(7,38,'api::media.media','object',1,42),(10,39,'api::media.media','object',1,43),(12,40,'api::media.media','object',1,44),(33,41,'api::media.media','object',1,45),(22,42,'api::media.media','object',1,46),(29,43,'api::media.media','object',1,47),(41,44,'api::media.media','object',1,48),(31,45,'api::media.media','object',1,49),(40,46,'api::media.media','object',1,50),(13,47,'api::media.media','object',1,51),(6,48,'api::media.media','object',1,52),(9,49,'api::media.media','object',1,53),(8,50,'api::media.media','object',1,54),(5,51,'api::media.media','object',1,55),(4,52,'api::media.media','object',1,56),(34,53,'api::media.media','object',1,57),(137,54,'api::media.media','object',1,58),(69,55,'api::media.media','object',1,59),(58,56,'api::media.media','object',1,60),(94,57,'api::media.media','object',1,61),(77,58,'api::media.media','object',1,62),(59,59,'api::media.media','object',1,63),(113,60,'api::media.media','object',1,64),(136,61,'api::media.media','object',1,65),(107,62,'api::media.media','object',1,66),(38,63,'api::media.media','object',1,67),(25,64,'api::media.media','object',1,68),(54,65,'api::media.media','object',1,69),(51,66,'api::media.media','object',1,70),(78,67,'api::media.media','object',1,71),(75,68,'api::media.media','object',1,72),(66,69,'api::media.media','object',1,73),(70,70,'api::media.media','object',1,74),(63,71,'api::media.media','object',1,75),(81,72,'api::media.media','object',1,76),(83,73,'api::media.media','object',1,77),(79,74,'api::media.media','object',1,78),(90,75,'api::media.media','object',1,79),(97,76,'api::media.media','object',1,80),(114,77,'api::media.media','object',1,81),(93,78,'api::media.media','object',1,82),(86,79,'api::media.media','object',1,83),(76,80,'api::media.media','object',1,84),(80,81,'api::media.media','object',1,85),(65,82,'api::media.media','object',1,86),(122,83,'api::media.media','object',1,87),(99,84,'api::media.media','object',1,88),(96,85,'api::media.media','object',1,89),(92,86,'api::media.media','object',1,90),(60,87,'api::media.media','object',1,91);
/*!40000 ALTER TABLE `files_related_morphs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 20:02:23
