-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_permissions_role_links`
--

DROP TABLE IF EXISTS `admin_permissions_role_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_permissions_role_links` (
  `permission_id` int unsigned DEFAULT NULL,
  `role_id` int unsigned DEFAULT NULL,
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `admin_permissions_role_links_fk` (`permission_id`),
  KEY `admin_permissions_role_links_inv_fk` (`role_id`),
  CONSTRAINT `admin_permissions_role_links_fk` FOREIGN KEY (`permission_id`) REFERENCES `admin_permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admin_permissions_role_links_inv_fk` FOREIGN KEY (`role_id`) REFERENCES `admin_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=419 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permissions_role_links`
--

LOCK TABLES `admin_permissions_role_links` WRITE;
/*!40000 ALTER TABLE `admin_permissions_role_links` DISABLE KEYS */;
INSERT INTO `admin_permissions_role_links` VALUES (1,2,1),(2,2,2),(3,2,3),(4,2,4),(5,2,5),(6,3,6),(7,3,7),(8,3,8),(9,3,9),(10,3,10),(14,1,11),(15,1,12),(16,1,13),(17,1,14),(18,1,15),(19,1,16),(20,1,17),(21,1,18),(22,1,19),(23,1,20),(24,1,21),(25,1,22),(26,1,23),(27,1,24),(28,1,25),(29,1,26),(30,1,27),(31,1,28),(32,1,29),(33,1,30),(34,1,31),(35,1,32),(36,1,33),(37,1,34),(38,1,35),(39,1,36),(40,1,37),(41,1,38),(42,1,39),(43,1,40),(44,1,41),(45,1,42),(46,1,43),(47,1,44),(48,1,45),(49,1,46),(50,1,47),(51,1,48),(52,1,49),(53,1,50),(54,1,51),(55,1,52),(56,1,53),(57,1,54),(58,1,55),(59,1,56),(60,1,57),(61,1,58),(62,1,59),(63,1,60),(64,1,61),(68,1,62),(69,1,63),(103,1,64),(104,1,65),(111,1,66),(112,1,67),(119,1,68),(120,1,69),(124,1,70),(125,1,71),(126,1,72),(127,1,73),(128,1,74),(129,1,75),(130,1,76),(131,1,77),(132,1,78),(139,1,79),(140,1,80),(141,1,81),(142,1,82),(143,1,83),(144,1,84),(145,1,85),(146,1,86),(319,1,90),(320,1,91),(321,1,92),(323,1,93),(327,1,97),(329,1,98),(330,1,99),(332,1,100),(333,1,101),(335,1,102),(336,1,103),(337,1,104),(338,1,105),(339,1,106),(361,1,107),(371,1,108),(422,1,109),(424,1,110),(426,1,111),(476,1,112),(478,1,113),(480,1,114),(693,1,257),(695,1,259),(697,1,261),(720,1,284),(745,1,309),(829,1,393),(831,1,395),(832,1,396),(833,1,397),(834,1,398),(836,1,400),(838,1,402),(839,1,403),(840,1,404),(841,1,405),(843,1,407),(845,1,409),(846,1,410),(847,1,411),(848,1,412),(849,1,413),(850,1,414),(851,1,415),(852,1,416),(853,1,417),(854,1,418);
/*!40000 ALTER TABLE `admin_permissions_role_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-17 22:11:56
