-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medias`
--

DROP TABLE IF EXISTS `medias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medias` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(255) DEFAULT NULL,
  `bearing` longtext,
  `description` longtext,
  `title` varchar(255) DEFAULT NULL,
  `action_type` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `featured_image` tinyint(1) DEFAULT NULL,
  `object_url` varchar(255) DEFAULT NULL,
  `reference_url` varchar(255) DEFAULT NULL,
  `citation` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `media_ui_path` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medias_created_by_id_fk` (`created_by_id`),
  KEY `medias_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `medias_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medias_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medias`
--

LOCK TABLES `medias` WRITE;
/*!40000 ALTER TABLE `medias` DISABLE KEYS */;
INSERT INTO `medias` VALUES (1,'0CE623BD-3E12-477D-B1B5-D43C2D590283',NULL,'Location Map','Location Map of N00282 Qisarah Valley South side  ––– وادي قصارة - الطرف الجنوبي','Location Map','N282.jpg',NULL,NULL,'2022-10-14 17:33:41.091000','2022-10-17 16:18:39.517000',1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'1BB2A48C-B3B2-4EA9-BC2B-3E96A1A7989C',NULL,'Location Map','Location Map of N00320 Birkat Aynuna ––– بركة قناة عَيْنُونَا','Location Map','N320.jpg',NULL,NULL,'2022-10-17 16:25:32.543000','2022-10-17 16:26:42.719000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(3,'A112F22C-3F49-4ECA-B78F-E6A7ECFB3100',NULL,'Location Map','Location Map of N00321 Qantarat Aynuna ––– قنطرة قناة عَيْنُونَا','Location Map','N321.jpg',NULL,NULL,'2022-10-17 16:29:34.620000','2022-10-17 16:29:34.620000',1,1,1,NULL,NULL,NULL,NULL,NULL,NULL),(4,'A231E76F-EA5E-4B15-9691-271792BA0FA1',NULL,'Location Map','Location Map of N00328 Aynuna ––– لوكِي كٌومي','Location Map','N328.jpg',NULL,NULL,'2022-10-17 16:31:30.575000','2022-10-17 16:31:30.575000',1,1,1,NULL,NULL,NULL,NULL,NULL,NULL),(5,'27D70C7A-3907-4E03-B917-33F8028B4984',NULL,'Location Map\n','Location Map of N00329 Aynuna ––– لوكِي كٌومي','Location Map','N329.jpg',NULL,NULL,'2022-10-17 16:34:12.670000','2022-10-17 16:34:30.592000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(6,'9E0B7333-5640-43C8-969A-FC59C84F1704',NULL,'Location Map\n','Location Map of N00330 Aynuna ––– لوكِي كٌومي ','Location Map','N330.jpg',NULL,NULL,'2022-10-17 16:52:49.501000','2022-10-17 17:14:31.397000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(7,'9076DF3D-952C-4387-A280-CCC510E68A4E',NULL,'Location Map\n','Location Map of N00331 Aynuna ––– لوكِي كٌومي','Location Map','N331.jpg',NULL,NULL,'2022-10-17 16:57:14.761000','2022-10-17 16:57:14.761000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(8,'CF7EE713-AC21-4659-9C49-5E5E223447FC',NULL,'Location Map\n','Location Map of N00332 Aynounah ––– لوكِي كٌومي ','Location Map','N332.jpg',NULL,NULL,'2022-10-17 16:58:46.845000','2022-10-17 16:58:46.845000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(9,'52B47A9E-235E-4BF8-BCBD-242D6297D6DB',NULL,'Location Map\n','Location Map of N00333 Aynounah ––– لوكِي كٌومي','Location Map','N333.jpg',NULL,NULL,'2022-10-17 17:00:08.095000','2022-10-17 17:00:08.095000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(10,'6B2C719B-84BE-48F5-9978-56A97912ADB5',NULL,'Location Map\n','Location Map of N00334 Aynounah ––– وكِي كٌومي','Location Map','N334.jpg',NULL,NULL,'2022-10-17 17:01:52.568000','2022-10-17 17:01:52.568000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(11,'C16336EA-83B7-4AD7-BC12-A88B8E4AA838',NULL,'Location Map\n','Location Map of N00370 Al-Muwaylih ––– الُموَيْلح - الحي التراثي ','Location Map','N370.jpg',NULL,NULL,'2022-10-17 18:03:02.309000','2022-10-17 18:03:02.309000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(12,'F7A715F8-D6A4-44F6-8F00-9B378C45FC4C',NULL,'Location Map\n','Location Map of N00371 Al-Muwaylih ––– الُموَيْلح - الحي التراثي ','Location Map','N371.jpg',NULL,NULL,'2022-10-17 18:05:28.352000','2022-10-17 18:05:28.352000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(13,'BA9768DA-774B-4A72-8FE9-CAB6E3655F87','S','Overview, N00282 Visit 1\n','Exclusion Overview of N00282 Visit 1','Exclusion Overview','Photo 7-11-2022 2.14.50 PM.jpg',34.802703,28.453238,'2022-10-17 18:08:05.981000','2022-10-17 18:08:05.981000',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL),(14,'06321407-7F1A-4ADE-990F-04FA874BA0CA','Detail\n','Overview, N00282 Visit 1\n','Feature Detail of N00282 Visit 1','Feature Detail','Photo 7-11-2022 2.21.49 PM.jpg',34.802212,28.453097,'2022-10-17 18:13:16.675000','2022-10-17 18:13:16.675000',1,1,0,NULL,NULL,NULL,NULL,NULL,0),(15,'5AF515F4-2BCC-4228-A7E7-FB3820423730','Detail\n','Overview, N00282 Visit 1\n','Feature Detail of N00282 Visit 1','Feature Detail','Photo 7-11-2022 2.22.09 PM.jpg',34.802212,28.453097,'2022-10-17 18:15:52.130000','2022-10-17 18:15:52.130000',1,1,0,NULL,NULL,NULL,NULL,NULL,0),(16,'8230F224-E458-4B75-BEB5-46DC7AA98F2C','Detail\n','Overview, N00282 Visit 1\n','Feature Detail of N00282 Visit 1','Feature Detail','Photo 7-11-2022 2.22.32 PM.jpg',34.802272,28.453188,'2022-10-17 18:18:03.094000','2022-10-17 18:18:03.094000',1,1,0,NULL,NULL,NULL,NULL,NULL,0),(17,'86AE4C5C-28A4-438E-8CB8-9D715361FD9E','Detail\n','Overview, N00282 Visit 1\n','Feature Detail of N00282 Visit 1','Feature Detail','Photo 7-11-2022 2.23.09 PM.jpg',34.802272,28.453188,'2022-10-17 18:21:07.099000','2022-10-17 18:21:07.099000',1,1,0,NULL,NULL,NULL,NULL,NULL,0),(18,'AC9F42E4-23F9-4B07-96A7-16BC7A4084D4','Detail\n','Overview, N00282 Visit 1\n','Feature Detail of N00282 Visit 1','Feature Detail','Photo 7-11-2022 2.17.08 PM.jpg',34.802563,28.453163,'2022-10-17 18:23:12.036000','2022-10-17 18:23:12.036000',1,1,0,NULL,NULL,NULL,NULL,NULL,0),(19,'B195648D-6FE5-4126-A443-4DD6B9A33414','Detail','Overview, N00282 Visit 1\n','Feature Detail of N00282 Visit 1','Feature Detail','Photo 7-11-2022 2.17.32 PM.jpg',34.802563,28.453163,'2022-10-17 18:30:48.890000','2022-10-17 18:30:48.890000',1,1,0,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `medias` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-17 22:11:57
