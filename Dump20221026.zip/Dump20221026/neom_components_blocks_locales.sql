-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_blocks_locales`
--

DROP TABLE IF EXISTS `components_blocks_locales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_blocks_locales` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `value` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_blocks_locales`
--

LOCK TABLES `components_blocks_locales` WRITE;
/*!40000 ALTER TABLE `components_blocks_locales` DISABLE KEYS */;
INSERT INTO `components_blocks_locales` VALUES (1,'Email'),(2,'البريد الإلكتروني'),(3,'Password'),(4,'كلمة المرور'),(5,'Sign in'),(6,'تسجيل الدخول'),(7,'Anchorage'),(8,'مرسى'),(9,'Artifact Scatter'),(10,'مبعثر قطعة أثرية'),(11,'Battlefield'),(12,'ساحة المعركة'),(13,'Inscription'),(14,'نقش'),(15,'Rock Art'),(16,'الفن الصخري'),(17,'Channel/Canal'),(18,'القناة / القناة'),(19,'Cleared area'),(20,'منطقة تم تطهيرها'),(21,'Settlement'),(22,'مستعمرة'),(23,'cemetery'),(24,'مقبرة'),(25,'Building'),(26,'مبنى'),(27,'Minor'),(28,'تحت السن القانوني'),(29,'National'),(30,'وطني'),(31,'Limited'),(32,'محدود'),(33,'International'),(34,'دولي'),(35,'Fair'),(36,'معرض'),(37,'Poor'),(38,'فقير'),(39,'Very Bad'),(40,'سيئ جدا'),(41,'No further action required'),(42,'لا يوجد اي اجراءات اخرى مطلوبه'),(43,'Protected'),(44,'محمي'),(45,'Protected and rehabilitated'),(46,'محمي وأعيد تأهيله'),(47,'Identifiable Threat'),(48,'تهديد يمكن تحديده'),(49,'Possible Threat'),(50,'تهديد محتمل'),(51,'Actively Damaged'),(52,'نشط الضرر'),(53,'Local'),(54,'محلي'),(55,'Modern'),(56,'عصري'),(57,'Islamic'),(58,'إسلامي'),(59,'Early'),(60,'مبكر'),(61,'Pre-Islamic'),(62,'ما قبل الإسلام'),(63,'Multi-Period'),(64,'متعدد الفترات'),(65,'Late'),(66,'متأخر'),(67,'Nabatean'),(68,'نبطي'),(69,'Roman'),(70,'رومان'),(71,'Unknown'),(72,'مجهول'),(73,'Ottoman'),(74,'العثماني'),(75,'Observed'),(76,'لاحظ'),(77,'Observed and photographed'),(78,'تمت ملاحظتها وتصويرها'),(79,'Collected'),(80,'جمعت'),(81,'Not observed'),(82,'لم يلاحظ'),(83,'Field-based'),(84,'ميداني قائم'),(85,'Remote sensing'),(86,'الاستشعار عن بعد'),(87,'Remote sensing verified in the field'),(88,'تم التحقق من الاستشعار عن بعد في الميدان'),(89,'Virtual'),(90,'افتراضية'),(91,'Boston dynamics robot'),(92,'روبوت بوسطن ديناميكس'),(93,'Good'),(94,'جيد'),(95,'Exceptional'),(96,'استثنائي'),(97,'Negligible'),(98,'ضئيلة');
/*!40000 ALTER TABLE `components_blocks_locales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-26 13:20:29
