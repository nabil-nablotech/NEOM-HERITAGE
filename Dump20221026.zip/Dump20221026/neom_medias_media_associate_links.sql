-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medias_media_associate_links`
--

DROP TABLE IF EXISTS `medias_media_associate_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medias_media_associate_links` (
  `media_id` int unsigned DEFAULT NULL,
  `media_associate_id` int unsigned DEFAULT NULL,
  KEY `medias_media_associate_links_fk` (`media_id`),
  KEY `medias_media_associate_links_inv_fk` (`media_associate_id`),
  CONSTRAINT `medias_media_associate_links_fk` FOREIGN KEY (`media_id`) REFERENCES `medias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `medias_media_associate_links_inv_fk` FOREIGN KEY (`media_associate_id`) REFERENCES `media_associates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medias_media_associate_links`
--

LOCK TABLES `medias_media_associate_links` WRITE;
/*!40000 ALTER TABLE `medias_media_associate_links` DISABLE KEYS */;
INSERT INTO `medias_media_associate_links` VALUES (140,2),(139,3),(138,4),(137,5),(136,6),(135,7),(134,8),(133,9),(132,10),(131,11),(130,12),(129,13),(128,14),(127,15),(126,16),(125,17),(124,18),(123,19),(122,20),(121,21),(120,22),(119,23),(118,24),(117,25),(116,26),(115,27),(114,28),(113,29),(112,30),(111,31),(110,32),(109,33),(108,36),(107,37),(106,38),(105,39),(104,40),(103,41),(102,42),(101,43),(100,44),(2,46),(3,47),(4,48),(5,49),(6,50),(7,51),(8,52),(9,53),(10,54),(11,55),(12,56),(13,57),(14,58),(15,59),(16,60),(17,61),(18,62),(19,63),(20,64),(21,65),(22,66),(23,67),(24,68),(25,69),(26,70),(27,71),(28,72),(29,73),(30,74),(31,75),(32,76),(33,77),(34,78),(35,79),(36,82),(37,83),(38,84),(39,85),(40,86),(41,87),(42,88),(43,89),(44,90),(45,91),(46,92),(47,93),(48,94),(49,95),(50,96),(51,97),(52,98),(53,99),(54,100),(55,101),(56,102),(57,103),(58,104),(59,105),(60,106),(61,107),(62,108),(63,109),(64,110),(65,111),(66,112),(67,113),(68,114),(69,115),(70,116),(71,117),(72,118),(73,119),(74,120),(75,121),(76,122),(77,123),(78,124),(79,125),(80,126),(81,127),(82,128),(83,129),(84,130),(85,131),(86,132),(87,133),(88,134),(89,135),(90,136),(91,137),(92,138),(93,139),(94,140),(95,141),(96,142),(97,143),(98,144),(99,145),(141,1),(1,45);
/*!40000 ALTER TABLE `medias_media_associate_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-26 13:20:24
