-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_blocks_locales_languages_links`
--

DROP TABLE IF EXISTS `components_blocks_locales_languages_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_blocks_locales_languages_links` (
  `locale_id` int unsigned DEFAULT NULL,
  `language_id` int unsigned DEFAULT NULL,
  KEY `components_blocks_locales_languages_links_fk` (`locale_id`),
  KEY `components_blocks_locales_languages_links_inv_fk` (`language_id`),
  CONSTRAINT `components_blocks_locales_languages_links_fk` FOREIGN KEY (`locale_id`) REFERENCES `components_blocks_locales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `components_blocks_locales_languages_links_inv_fk` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_blocks_locales_languages_links`
--

LOCK TABLES `components_blocks_locales_languages_links` WRITE;
/*!40000 ALTER TABLE `components_blocks_locales_languages_links` DISABLE KEYS */;
INSERT INTO `components_blocks_locales_languages_links` VALUES (1,1),(2,2),(3,1),(4,2),(5,1),(6,2),(7,1),(8,2),(9,1),(10,2),(11,1),(12,2),(13,1),(14,2),(17,1),(18,2),(19,1),(20,2),(21,1),(22,2),(23,1),(24,2),(25,1),(26,2),(55,1),(56,2),(57,1),(58,2),(59,1),(60,2),(61,1),(62,2),(63,1),(64,2),(65,1),(66,2),(67,1),(68,2),(69,1),(70,2),(71,1),(72,2),(73,1),(74,2),(75,1),(76,2),(77,1),(78,2),(79,1),(80,2),(81,1),(82,2),(83,1),(84,2),(85,1),(86,2),(87,1),(88,2),(89,1),(90,2),(91,1),(92,2),(109,1),(110,2),(111,1),(112,2),(113,1),(114,2),(115,1),(116,2),(117,1),(118,2),(125,1),(126,2),(16,2),(15,1),(128,2),(127,1),(124,2),(123,1),(122,2),(121,1),(120,2),(119,1),(39,1),(40,2),(37,1),(38,2),(35,1),(36,2),(93,1),(94,2),(95,1),(96,2),(45,1),(46,2),(43,1),(44,2),(41,1),(42,2),(27,1),(28,2),(103,1),(104,2),(97,1),(98,2),(105,1),(106,2),(29,1),(30,2),(33,1),(34,2),(101,1),(102,2),(31,1),(32,2),(99,1),(100,2),(49,1),(50,2),(47,1),(48,2),(51,1),(52,2),(107,1),(108,2),(53,1),(54,2),(129,1),(130,2),(131,1),(132,2),(133,1),(134,2),(135,1),(136,2),(137,1),(138,2),(139,1),(140,2),(141,1),(142,2),(143,1),(144,2),(145,1),(146,2),(147,1),(148,2),(149,1),(150,2),(151,1),(152,2),(153,1),(154,2),(156,1),(157,2),(158,1),(159,2),(160,1),(161,2),(163,2),(162,1),(164,1),(165,2),(166,1),(167,2),(168,1),(169,2),(170,1),(171,2),(172,1),(173,2),(174,1),(175,2),(176,1),(177,2),(180,1),(181,2),(179,2),(178,1),(182,1),(183,2),(184,1),(185,2),(186,1),(187,2),(188,1),(189,2),(190,1),(191,2),(192,1),(193,2),(194,1),(195,2),(196,1),(197,2),(198,1),(199,2),(200,1),(201,2),(202,1),(203,2),(204,1),(205,2),(206,1),(155,2),(207,1),(208,2),(209,1),(212,2),(211,1),(213,1),(214,2),(215,1),(216,2),(217,1),(218,2),(219,1),(220,2),(221,1),(222,2),(223,1),(224,2),(227,1),(228,2),(229,1),(230,2),(231,1),(232,2),(233,1),(234,2),(235,1),(236,2),(237,1),(238,2),(239,1),(240,2),(241,1),(242,2),(243,1),(244,2),(245,1),(246,2),(247,1),(248,2),(249,1),(250,2),(251,1),(252,2),(225,1),(226,2),(253,1),(254,2);
/*!40000 ALTER TABLE `components_blocks_locales_languages_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-28 13:23:20
