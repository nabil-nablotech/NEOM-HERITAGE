-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `visits`
--

DROP TABLE IF EXISTS `visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visits` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `visit_date` date DEFAULT NULL,
  `recording_team` varchar(255) DEFAULT NULL,
  `visit_number` int DEFAULT NULL,
  `field_narrative` longtext,
  `assessment_type` varchar(255) DEFAULT NULL,
  `artifacts` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `unique_id` varchar(255) DEFAULT NULL,
  `site_description` longtext,
  `period` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `visit_ui_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visits_created_by_id_fk` (`created_by_id`),
  KEY `visits_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `visits_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visits_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visits`
--

LOCK TABLES `visits` WRITE;
/*!40000 ALTER TABLE `visits` DISABLE KEYS */;
INSERT INTO `visits` VALUES (1,'2022-06-28','Alexandra Case; Ben Fischer',1,'Documentation of the area would’ve been quite extensive; therefore, a small collection of details has been provided and marked in GIS one through seven. The area does seem to have quite a bit of human disturbance including modern markings and vehicle tracks. The surrounding area has rocky dunes with limited shrubbery and sand roadways. No additional artifacts were seen, and 24 photos were taken. ',NULL,NULL,'2022-10-14 16:30:11.240000','2022-10-14 17:03:59.693000','2022-10-14 17:03:59.684000',1,1,'C03DFE9A-F7DE-4182-9DC2-F73EA4681998','Pre-Islamic, Islamic, and modern inscription/rock art site. The site, located at the base of a cliff face in a wadi system, consists of an aeolian sandstone formation, approximately 2.5 to 3 m in height and 12 to 15 m in length. Inscriptions in Arabic and English are present on the north face of the sandstone formation and continue down onto a small flat area at the base. Arabic numerals, several written as dates, are also inscribed in this area. Additional carvings include hands, feet, possible animals, and linear markings. There are several deeper linear grooves running vertically north to south along the face of the sandstone formation with evidence of tire tracks. Possibly related to site N283 located on the opposite side of the wadi.','Modern; Islamic, Early; Pre-Islamic; Multi-Period',28.453292,34.80304,'Visit',0,NULL,NULL),(2,'2022-07-08','Adam Biernaski; Dan Shelton',1,'The site is in a low-lying area adjacent to a fence and is possibly already disturbed by power line construction. No artifacts were noted at or around the site. Four photos were taken. Part of a larger feature which may include N00316 and N321. The channel is similar in construction to site N00321 and is likely the continuation or termination of that feature. The square rock structure may have been the outline of a water collection point or pool.',NULL,NULL,'2022-10-14 16:30:13.921000','2022-10-14 17:03:53.706000','2022-10-14 17:03:53.698000',1,1,'D620C47A-06B8-4957-B2F8-1465823F75C3','Late pre-Islamic/Islamic channel and cleared area. The site, located in a low-lying area between Wadi Aynounah and the historical harbor at al-Khuraybah, consists of a stone and gypsum channel that runs 80 m and terminates in a square rock structure that was cleared on the inside and measured approximately 25 m along each side. The cleared area bordered by stones might have been the outline of a water collection point or pool. The construction technique and location suggest that it was part of the same channel/pool system as sites N316 and N321 nearby.  ','Pre-Islamic; Islamic, Late',28.075133,35.17755,'Visit',0,NULL,NULL),(3,'2022-06-17','Adam Biernaski; Dan Shelton',1,'No artifacts were found, and 4 photos were taken. A linear point of the length of the feature was also traced in GIS. Related to sites N00316 and N00320 which have channels of similar construction.',NULL,NULL,'2022-10-14 16:30:16.454000','2022-10-14 17:04:04.908000','2022-10-14 17:04:04.900000',1,1,'C267360A-EC5E-4769-A9B7-4CD04B49A543','Late pre-Islamic/Islamic/Modern channel. The site, located in a low-lying area between Wadi Aynounah and the historical harbor at al-Khuraybah, consists of a linear channel that runs north to south for approximately 125 m. The channel is 1 m wide on average along its length. It has a rock and concretion mixture foundation and a sandstone base and walls. There is no evidence that the channel was covered. There is a small path that bisected the feature near its preserved midpoint. Part of the same channel/pool system as sites N316 and N320 nearby, although it may have been reworked in the modern period based on the different style of construction evidence along part of its length.; ','Pre-Islamic; Islamic, Late; Modern?',28.077201,35.177896,'Visit',0,NULL,NULL),(4,'2022-07-07','Adam Biernaski; Dan Shelton',1,'Should be associated with the settlement located at N00327. The site was previously excavated by a joint Saudi and Polish team (they labeled the site ‘Upper Aynuna’) and several locations in the site showed evidence of having been excavated previously. Grinding stones and two diagnostic pieces of ceramic were photographed but not collected. Due to the size of the structure the site boundary was manually input and not taken from GPS. A total of 11 photos were taken of the site. Outside of the site area there are additional walls in the region and possibly other small fortifications. A second large terrace, approximately 10 m lower in elevation, exists to the southwest with a wall and foundation structures. ',NULL,NULL,'2022-10-14 16:30:18.383000','2022-10-14 16:59:19.265000',NULL,1,1,'43DE0BCF-AE6C-46DC-AA34-E8876A0FB5E2','Nabataean and Roman settlement. The settlement, located on multiple terraces northeast of site N327, consists of a walled town or fortress with the remains of 80+ structures. The walls are preserved to an average of 1.5 m in height. There were considerable artifacts found scattered throughout the site including ceramics and lithics. Several of the ceramics were identified as Nabataean. On the northern boundary of the site there is a wall that may have been part of a tower or fortification. The site was previously surveyed by a joint Saudi and Polish team who labeled the site ‘Upper Aynuna’. Part of the Nabataean settlement system in Wadi Aynounah (with sites N323 and N327).','Nabatean; Roman',28.089352,35.185602,'Visit',0,NULL,NULL),(5,'2022-06-17','Adam Biernaski; Dan Shelton',1,'No artifacts were detected on the surface. If this is in fact a cemetery, we should count ourselves lucky that it may still be intact and not looted like other ones to the northwest. A single depression was cited slightly north of the cliff face which may have been a small test pit for potential looting but otherwise no human occupation modern or otherwise is detected. A total of 6 photos were taken. A single lithic tool was found, a point taken, and it was photographed but not collected.; ',NULL,NULL,'2022-10-14 16:30:20.109000','2022-10-14 17:04:14.997000','2022-10-14 17:04:14.991000',1,1,'200D4805-7549-497D-B3C1-6DCBD830BDD7','Cemetery of unknown date. The cemetery, located on a plateau on top of a cliff, consists of a stone scatter indicating the presence of undisturbed shaft tombs. There are no structures on top of the hill, however, the area is similar to several of the looted cemeteries nearby and there are several cairn structures on a lower terrace on the southern cliff face. Possibly part of a group of Nabataean cemeteries located to the northwest of the Nabataean settlements in Wadi Aynounah (N329-N334).','Unknown',28.089992,35.183237,'Visit',0,NULL,NULL);
/*!40000 ALTER TABLE `visits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-14 18:24:16
