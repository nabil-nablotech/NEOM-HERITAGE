-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `visits`
--

DROP TABLE IF EXISTS `visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visits` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `visit_date` date DEFAULT NULL,
  `recording_team` varchar(255) DEFAULT NULL,
  `visit_number` int DEFAULT NULL,
  `field_narrative` longtext,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `unique_id` varchar(255) DEFAULT NULL,
  `site_description` longtext,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `visit_ui_path` varchar(255) DEFAULT NULL,
  `site_type` json DEFAULT NULL,
  `research_value` json DEFAULT NULL,
  `artifacts` json DEFAULT NULL,
  `tourism_value` json DEFAULT NULL,
  `state_of_conservation` json DEFAULT NULL,
  `recommendation` json DEFAULT NULL,
  `risk` json DEFAULT NULL,
  `period` json DEFAULT NULL,
  `assessment_type` json DEFAULT NULL,
  `keywords` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visits_created_by_id_fk` (`created_by_id`),
  KEY `visits_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `visits_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visits_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visits`
--

LOCK TABLES `visits` WRITE;
/*!40000 ALTER TABLE `visits` DISABLE KEYS */;
INSERT INTO `visits` VALUES (1,'2022-11-07','Alexandra Case; Ben Fischer',1,'Documentation of the area would’ve been quite extensive; therefore, a small collection of details has been provided and marked in GIS one through seven. The area does seem to have quite a bit of human disturbance including modern markings and vehicle tracks. The surrounding area has rocky dunes with limited shrubbery and sand roadways. No additional artifacts were seen, and 24 photos were taken. ','2022-11-09 12:27:31.195000','2022-11-10 08:45:27.562000',NULL,NULL,'SEGIK68X-EBNR-FPHV-S0HN-HBKHYRFLRGFJ','Pre-Islamic, Islamic, and modern inscription/rock art site. The site, located at the base of a cliff face in a wadi system, consists of an aeolian sandstone formation, approximately 2.5 to 3 m in height and 12 to 15 m in length. Inscriptions in Arabic and English are present on the north face of the sandstone formation and continue down onto a small flat area at the base. Arabic numerals, several written as dates, are also inscribed in this area. Additional carvings include hands, feet, possible animals, and linear markings. There are several deeper linear grooves running vertically north to south along the face of the sandstone formation with evidence of tire tracks. Possibly related to site N283 located on the opposite side of the wadi.',28.453292,35.177896,0,'http://localhost:3000/search-results/Events/SEGIK68X-EBNR-FPHV-S0HN-HBKHYRFLRGFJ','[\"Anchorage\", \"Artifact Scatter\"]','[\"4.International\"]','[\"Observed\"]','[\"3.National\"]','[\"3.Fair\"]','[\"1.Protected\"]','[\"2.Possible Threat\"]','[\"Multi-Period\", \"Late\"]','[\"Field-based\"]','[\"Egrp1\"]'),(2,'2022-11-08','',1,'The site is in a low-lying area adjacent to a fence and is possibly already disturbed by power line construction. No artifacts were noted at or around the site. Four photos were taken. Part of a larger feature which may include N00316 and N321. The channel is similar in construction to site N00321 and is likely the continuation or termination of that feature. The square rock structure may have been the outline of a water collection point or pool.','2022-11-09 12:49:13.338000','2022-11-10 08:44:47.824000',NULL,1,'1TG1HAFN-7BZQ-FMAH-YFR7-J2YCFA5EQDP2','',28.075133,34.80304,0,'http://localhost:3000/search-results/Events/1TG1HAFN-7BZQ-FMAH-YFR7-J2YCFA5EQDP2','[\"Inscription\", \"Rock art\"]','[\"4.International\"]','[\"Observed\"]','[\"3.National\"]','[\"3.Fair\"]','[\"2.Protected and rehabilitated\"]','[\"2.Possible Threat\"]','[\"Islamic\", \"Multi-Period\"]','[\"Remote sensing\"]','[\"Egrp2\"]'),(3,'2022-11-08','',1,'No artifacts were found, and 4 photos were taken. A linear point of the length of the feature was also traced in GIS. Related to sites N00316 and N00320 which have channels of similar construction.','2022-11-09 12:51:25.276000','2022-11-10 08:45:11.110000',NULL,NULL,'SRECABLI-WZEH-6XTH-HXID-YPSIFB42RZ8W','Late pre-Islamic/Islamic/Modern channel. The site, located in a low-lying area between Wadi Aynounah and the historical harbor at al-Khuraybah, consists of a linear channel that runs north to south for approximately 125 m. The channel is 1 m wide on average along its length. It has a rock and concretion mixture foundation and a sandstone base and walls. There is no evidence that the channel was covered. There is a small path that bisected the feature near its preserved midpoint. Part of the same channel/pool system as sites N316 and N320 nearby, although it may have been reworked in the modern period based on the different style of construction evidence along part of its length.; ',28.077201,35.17755,0,'http://localhost:3000/search-results/Events/SRECABLI-WZEH-6XTH-HXID-YPSIFB42RZ8W','[\"Rock art\"]','[\"3.National\"]','[\"Collected\"]','[\"2.Limited\"]','[\"2.Poor\"]','[\"0.No further action required\"]','[\"1.No Threat\"]','[\"Ottoman\"]','[\"Remote sensing verified in the field\"]','[\"Egrp3\"]'),(4,'2022-11-10','',2,'Documentation of the area would’ve been quite extensive; therefore, a small collection of details has been provided and marked in GIS one through seven. The area does seem to have quite a bit of human disturbance including modern markings and vehicle tracks. The surrounding area has rocky dunes with limited shrubbery and sand roadways. No additional artifacts were seen, and 24 photos were taken. ','2022-11-10 08:49:04.554000','2022-11-10 08:49:04.554000',NULL,NULL,'CWSROAZR-DIF9-LSWB-4JK0-JDADJBGB6BNB','Pre-Islamic, Islamic, and modern inscription/rock art site. The site, located at the base of a cliff face in a wadi system, consists of an aeolian sandstone formation, approximately 2.5 to 3 m in height and 12 to 15 m in length. Inscriptions in Arabic and English are present on the north face of the sandstone formation and continue down onto a small flat area at the base. Arabic numerals, several written as dates, are also inscribed in this area. Additional carvings include hands, feet, possible animals, and linear markings. There are several deeper linear grooves running vertically north to south along the face of the sandstone formation with evidence of tire tracks. Possibly related to site N283 located on the opposite side of the wadi.',28.45329,34.803,0,'http://localhost:3000/search-results/Events/CWSROAZR-DIF9-LSWB-4JK0-JDADJBGB6BNB','[\"Artifact Scatter\", \"Inscription\"]','[\"2.Limited\"]','[\"Observed\"]','[\"3.National\"]','[\"2.Poor\"]','[\"1.Protected\"]','[\"3.Identifiable Threat\"]','[\"Islamic\", \"Multi-Period\"]','[\"Remote sensing\"]','[\"egrp1\"]');
/*!40000 ALTER TABLE `visits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-15 21:39:07
