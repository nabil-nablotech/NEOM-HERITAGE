-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `media_associates_visit_unique_id_links`
--

DROP TABLE IF EXISTS `media_associates_visit_unique_id_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_associates_visit_unique_id_links` (
  `media_associate_id` int unsigned DEFAULT NULL,
  `visit_id` int unsigned DEFAULT NULL,
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `media_associates_visit_unique_id_links_fk` (`media_associate_id`),
  KEY `media_associates_visit_unique_id_links_inv_fk` (`visit_id`),
  CONSTRAINT `media_associates_visit_unique_id_links_fk` FOREIGN KEY (`media_associate_id`) REFERENCES `media_associates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_associates_visit_unique_id_links_inv_fk` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_associates_visit_unique_id_links`
--

LOCK TABLES `media_associates_visit_unique_id_links` WRITE;
/*!40000 ALTER TABLE `media_associates_visit_unique_id_links` DISABLE KEYS */;
INSERT INTO `media_associates_visit_unique_id_links` VALUES (1,11,1),(2,10,2),(3,9,3),(4,8,4),(5,7,5),(6,6,6),(7,5,7),(8,4,8),(9,3,9),(10,2,10),(11,11,11),(12,11,12),(13,11,13),(14,11,14),(15,11,15),(16,10,16),(17,10,17),(18,10,18),(19,10,19),(20,9,20),(21,9,21),(22,8,22),(23,8,23),(24,8,24),(25,8,25),(26,8,26),(27,8,27),(28,8,28),(29,8,29),(30,8,30),(31,8,31),(32,7,32),(33,7,33),(36,7,36),(37,7,37),(38,7,38),(39,7,39),(40,7,40),(41,6,41),(42,6,42),(43,5,43),(44,5,44),(57,1,45),(58,1,46),(59,1,47),(60,1,48),(61,1,49),(62,1,50),(63,1,51),(64,1,52),(65,1,53),(66,1,54),(67,1,55),(68,1,56),(69,1,57),(70,1,58),(71,1,59),(72,1,60),(73,1,61),(74,1,62),(75,1,63),(76,1,64),(77,1,65),(78,1,66),(79,1,67),(82,1,70),(83,1,71),(84,1,72),(85,1,73),(86,1,74),(87,1,75),(88,1,76),(89,1,77),(90,1,78),(91,1,79),(92,1,80),(93,1,81),(94,1,82),(95,1,83),(96,1,84),(97,1,85),(98,1,86),(99,1,87),(100,4,88),(101,4,89),(102,4,90),(103,4,91),(104,5,92),(105,5,93),(106,8,94),(107,11,95),(108,11,96),(109,2,97),(110,2,98),(111,3,99),(112,3,100),(113,4,101),(114,5,102),(115,6,103),(116,6,104),(117,6,105),(118,6,106),(119,6,107),(120,6,108),(121,7,109),(122,7,110),(123,7,111),(124,7,112),(125,9,113),(126,9,114),(127,9,115),(128,9,116),(129,7,117),(130,7,118),(131,8,119),(132,4,120),(133,4,121),(134,2,122),(135,2,123),(136,3,124),(137,3,125),(138,4,126),(139,4,127),(140,4,128),(141,4,129),(142,4,130),(143,4,131),(144,4,132),(145,5,133);
/*!40000 ALTER TABLE `media_associates_visit_unique_id_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-20 20:26:09
