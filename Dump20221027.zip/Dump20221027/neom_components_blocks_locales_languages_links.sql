-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_blocks_locales_languages_links`
--

DROP TABLE IF EXISTS `components_blocks_locales_languages_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_blocks_locales_languages_links` (
  `locale_id` int unsigned DEFAULT NULL,
  `language_id` int unsigned DEFAULT NULL,
  KEY `components_blocks_locales_languages_links_fk` (`locale_id`),
  KEY `components_blocks_locales_languages_links_inv_fk` (`language_id`),
  CONSTRAINT `components_blocks_locales_languages_links_fk` FOREIGN KEY (`locale_id`) REFERENCES `components_blocks_locales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `components_blocks_locales_languages_links_inv_fk` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_blocks_locales_languages_links`
--

LOCK TABLES `components_blocks_locales_languages_links` WRITE;
/*!40000 ALTER TABLE `components_blocks_locales_languages_links` DISABLE KEYS */;
INSERT INTO `components_blocks_locales_languages_links` VALUES (1,1),(2,2),(3,1),(4,2),(5,1),(6,2),(7,1),(8,2),(9,1),(10,2),(11,1),(12,2),(13,1),(14,2),(17,1),(18,2),(19,1),(20,2),(21,1),(22,2),(23,1),(24,2),(25,1),(26,2),(27,1),(28,2),(31,1),(32,2),(33,1),(34,2),(35,1),(36,2),(37,1),(38,2),(41,1),(42,2),(43,1),(44,2),(45,1),(46,2),(47,1),(48,2),(49,1),(50,2),(51,1),(52,2),(39,1),(40,2),(29,1),(30,2),(53,1),(54,2),(55,1),(56,2),(57,1),(58,2),(59,1),(60,2),(61,1),(62,2),(63,1),(64,2),(65,1),(66,2),(67,1),(68,2),(69,1),(70,2),(71,1),(72,2),(73,1),(74,2),(75,1),(76,2),(77,1),(78,2),(79,1),(80,2),(81,1),(82,2),(83,1),(84,2),(85,1),(86,2),(87,1),(88,2),(89,1),(90,2),(91,1),(92,2),(93,1),(94,2),(95,1),(96,2),(97,1),(98,2),(99,1),(100,2),(101,1),(102,2),(103,1),(104,2),(105,1),(106,2),(108,2),(109,1),(110,2),(111,1),(112,2),(113,1),(114,2),(115,1),(116,2),(117,1),(118,2),(119,1),(120,2),(121,1),(122,2),(123,1),(124,2),(125,1),(126,2),(127,1),(128,2),(16,2),(15,1);
/*!40000 ALTER TABLE `components_blocks_locales_languages_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-27 14:09:36
