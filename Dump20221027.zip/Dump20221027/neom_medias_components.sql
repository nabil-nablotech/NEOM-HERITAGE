-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medias_components`
--

DROP TABLE IF EXISTS `medias_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medias_components` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity_id` int unsigned DEFAULT NULL,
  `component_id` int unsigned DEFAULT NULL,
  `component_type` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `order` int unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `medias_field_index` (`field`),
  KEY `medias_component_type_index` (`component_type`),
  KEY `medias_entity_fk` (`entity_id`),
  CONSTRAINT `medias_entity_fk` FOREIGN KEY (`entity_id`) REFERENCES `medias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medias_components`
--

LOCK TABLES `medias_components` WRITE;
/*!40000 ALTER TABLE `medias_components` DISABLE KEYS */;
INSERT INTO `medias_components` VALUES (6,2,3,'blocks.common-fields','imageMetadata',1),(7,3,4,'blocks.common-fields','imageMetadata',1),(8,4,5,'blocks.common-fields','imageMetadata',1),(11,5,6,'blocks.common-fields','imageMetadata',1),(13,7,8,'blocks.common-fields','imageMetadata',1),(14,8,9,'blocks.common-fields','imageMetadata',1),(15,9,10,'blocks.common-fields','imageMetadata',1),(16,10,11,'blocks.common-fields','imageMetadata',1),(17,6,7,'blocks.common-fields','imageMetadata',1),(18,11,12,'blocks.common-fields','imageMetadata',1),(19,12,13,'blocks.common-fields','imageMetadata',1),(20,13,14,'blocks.common-fields','imageMetadata',1),(21,14,15,'blocks.common-fields','imageMetadata',1),(22,15,16,'blocks.common-fields','imageMetadata',1),(23,16,17,'blocks.common-fields','imageMetadata',1),(24,17,18,'blocks.common-fields','imageMetadata',1),(25,18,19,'blocks.common-fields','imageMetadata',1),(26,19,20,'blocks.common-fields','imageMetadata',1),(27,20,21,'blocks.common-fields','imageMetadata',1),(28,21,22,'blocks.common-fields','imageMetadata',1),(31,24,25,'blocks.common-fields','imageMetadata',1),(32,23,24,'blocks.common-fields','imageMetadata',1),(33,22,23,'blocks.common-fields','imageMetadata',1),(34,25,26,'blocks.common-fields','imageMetadata',1),(35,26,27,'blocks.common-fields','imageMetadata',1),(36,27,28,'blocks.common-fields','imageMetadata',1),(40,30,31,'blocks.common-fields','imageMetadata',1),(41,29,30,'blocks.common-fields','imageMetadata',1),(42,28,29,'blocks.common-fields','imageMetadata',1),(43,31,32,'blocks.common-fields','imageMetadata',1),(44,32,33,'blocks.common-fields','imageMetadata',1),(45,33,34,'blocks.common-fields','imageMetadata',1),(46,34,35,'blocks.common-fields','imageMetadata',1),(47,35,36,'blocks.common-fields','imageMetadata',1),(48,36,37,'blocks.common-fields','imageMetadata',1),(49,37,38,'blocks.common-fields','imageMetadata',1),(50,38,39,'blocks.common-fields','imageMetadata',1),(51,39,40,'blocks.common-fields','imageMetadata',1),(52,40,41,'blocks.common-fields','imageMetadata',1),(53,41,42,'blocks.common-fields','imageMetadata',1),(54,42,43,'blocks.common-fields','imageMetadata',1),(55,43,44,'blocks.common-fields','imageMetadata',1),(56,44,45,'blocks.common-fields','imageMetadata',1),(57,45,46,'blocks.common-fields','imageMetadata',1),(58,46,47,'blocks.common-fields','imageMetadata',1),(59,47,48,'blocks.common-fields','imageMetadata',1),(60,48,49,'blocks.common-fields','imageMetadata',1),(61,49,50,'blocks.common-fields','imageMetadata',1),(62,50,51,'blocks.common-fields','imageMetadata',1),(63,51,52,'blocks.common-fields','imageMetadata',1),(64,52,53,'blocks.common-fields','imageMetadata',1),(65,53,54,'blocks.common-fields','imageMetadata',1),(66,54,55,'blocks.common-fields','imageMetadata',1),(67,55,56,'blocks.common-fields','imageMetadata',1),(68,56,57,'blocks.common-fields','imageMetadata',1),(69,57,58,'blocks.common-fields','imageMetadata',1),(70,58,59,'blocks.common-fields','imageMetadata',1),(71,59,60,'blocks.common-fields','imageMetadata',1),(72,60,61,'blocks.common-fields','imageMetadata',1),(73,61,62,'blocks.common-fields','imageMetadata',1),(74,62,63,'blocks.common-fields','imageMetadata',1),(75,63,64,'blocks.common-fields','imageMetadata',1),(76,64,65,'blocks.common-fields','imageMetadata',1),(77,65,66,'blocks.common-fields','imageMetadata',1),(78,66,67,'blocks.common-fields','imageMetadata',1),(79,67,68,'blocks.common-fields','imageMetadata',1),(80,68,69,'blocks.common-fields','imageMetadata',1),(81,69,70,'blocks.common-fields','imageMetadata',1),(82,70,71,'blocks.common-fields','imageMetadata',1),(83,71,72,'blocks.common-fields','imageMetadata',1),(84,72,73,'blocks.common-fields','imageMetadata',1),(85,73,74,'blocks.common-fields','imageMetadata',1),(86,74,75,'blocks.common-fields','imageMetadata',1),(87,75,76,'blocks.common-fields','imageMetadata',1),(88,76,77,'blocks.common-fields','imageMetadata',1),(89,77,78,'blocks.common-fields','imageMetadata',1),(90,78,79,'blocks.common-fields','imageMetadata',1),(91,79,80,'blocks.common-fields','imageMetadata',1),(92,80,81,'blocks.common-fields','imageMetadata',1),(93,81,82,'blocks.common-fields','imageMetadata',1),(94,82,83,'blocks.common-fields','imageMetadata',1),(95,83,84,'blocks.common-fields','imageMetadata',1),(96,84,85,'blocks.common-fields','imageMetadata',1),(97,85,86,'blocks.common-fields','imageMetadata',1),(98,86,87,'blocks.common-fields','imageMetadata',1),(99,87,88,'blocks.common-fields','imageMetadata',1),(100,88,89,'blocks.common-fields','imageMetadata',1),(101,89,90,'blocks.common-fields','imageMetadata',1),(102,90,91,'blocks.common-fields','imageMetadata',1),(103,91,92,'blocks.common-fields','imageMetadata',1),(104,92,93,'blocks.common-fields','imageMetadata',1),(105,93,94,'blocks.common-fields','imageMetadata',1),(106,94,95,'blocks.common-fields','imageMetadata',1),(107,95,96,'blocks.common-fields','imageMetadata',1),(108,96,97,'blocks.common-fields','imageMetadata',1),(109,97,98,'blocks.common-fields','imageMetadata',1),(110,98,99,'blocks.common-fields','imageMetadata',1),(111,99,100,'blocks.common-fields','imageMetadata',1),(112,100,101,'blocks.common-fields','imageMetadata',1),(113,101,102,'blocks.common-fields','imageMetadata',1),(114,102,103,'blocks.common-fields','imageMetadata',1),(115,103,104,'blocks.common-fields','imageMetadata',1),(116,104,105,'blocks.common-fields','imageMetadata',1),(117,105,106,'blocks.common-fields','imageMetadata',1),(119,106,107,'blocks.common-fields','imageMetadata',1),(120,107,108,'blocks.common-fields','imageMetadata',1),(121,108,109,'blocks.common-fields','imageMetadata',1),(122,109,110,'blocks.common-fields','imageMetadata',1),(123,110,111,'blocks.common-fields','imageMetadata',1),(124,111,112,'blocks.common-fields','imageMetadata',1),(125,112,113,'blocks.common-fields','imageMetadata',1),(126,113,114,'blocks.common-fields','imageMetadata',1),(127,114,115,'blocks.common-fields','imageMetadata',1),(128,115,116,'blocks.common-fields','imageMetadata',1),(129,116,117,'blocks.common-fields','imageMetadata',1),(131,117,118,'blocks.common-fields','imageMetadata',1),(132,118,119,'blocks.common-fields','imageMetadata',1),(133,119,120,'blocks.common-fields','imageMetadata',1),(134,120,121,'blocks.common-fields','imageMetadata',1),(135,121,122,'blocks.common-fields','imageMetadata',1),(136,122,123,'blocks.common-fields','imageMetadata',1),(137,123,124,'blocks.common-fields','imageMetadata',1),(138,124,125,'blocks.common-fields','imageMetadata',1),(139,125,126,'blocks.common-fields','imageMetadata',1),(140,126,127,'blocks.common-fields','imageMetadata',1),(141,127,128,'blocks.common-fields','imageMetadata',1),(142,128,129,'blocks.common-fields','imageMetadata',1),(143,129,130,'blocks.common-fields','imageMetadata',1),(144,130,131,'blocks.common-fields','imageMetadata',1),(145,131,132,'blocks.common-fields','imageMetadata',1),(146,132,133,'blocks.common-fields','imageMetadata',1),(147,133,134,'blocks.common-fields','imageMetadata',1),(148,134,135,'blocks.common-fields','imageMetadata',1),(150,135,136,'blocks.common-fields','imageMetadata',1),(151,136,137,'blocks.common-fields','imageMetadata',1),(152,137,138,'blocks.common-fields','imageMetadata',1),(153,138,139,'blocks.common-fields','imageMetadata',1),(154,139,140,'blocks.common-fields','imageMetadata',1),(155,140,141,'blocks.common-fields','imageMetadata',1),(157,141,142,'blocks.common-fields','imageMetadata',1),(158,1,2,'blocks.common-fields','imageMetadata',1);
/*!40000 ALTER TABLE `medias_components` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-27 14:09:34
