-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `places` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `previous_number` varchar(255) DEFAULT NULL,
  `place_number` varchar(255) DEFAULT NULL,
  `place_name_english` varchar(255) DEFAULT NULL,
  `place_name_arabic` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `unique_id` varchar(255) DEFAULT NULL,
  `site_description` longtext,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `place_ui_path` varchar(255) DEFAULT NULL,
  `place_value` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `places_created_by_id_fk` (`created_by_id`),
  KEY `places_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `places_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `places_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `places`
--

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (1,NULL,'N00282','Qisarah Valley South side ','وادي قصارة - الطرف الجنوبي','2022-10-17 13:20:53.069000','2022-10-18 17:41:38.897000',1,1,'0B3D41DD-707D-49E0-9C24-40D7F9325D95','Pre-Islamic, Islamic, and modern inscription/rock art site. The site, located at the base of a cliff face in a wadi system, consists of an aeolian sandstone formation, approximately 2.5 to 3 m in height and 12 to 15 m in length. Inscriptions in Arabic and English are present on the north face of the sandstone formation and continue down onto a small flat area at the base. Arabic numerals, several written as dates, are also inscribed in this area. Additional carvings include hands, feet, possible animals, and linear markings. There are several deeper linear grooves running vertically north to south along the face of the sandstone formation with evidence of tire tracks. Possibly related to site N283 located on the opposite side of the wadi.',28.453,34.80304,'Site',0,NULL,NULL,NULL),(2,NULL,'N00320','Birkat Aynuna','بركة قناة عَيْنُونَا','2022-10-17 13:20:54.496000','2022-10-18 17:41:51.291000',1,1,'8A571BD1-1285-4853-9C25-F10978D5BC67','Late pre-Islamic/Islamic channel and cleared area. The site, located in a low-lying area between Wadi Aynounah and the historical harbor at al-Khuraybah, consists of a stone and gypsum channel that runs 80 m and terminates in a square rock structure that was cleared on the inside and measured approximately 25 m along each side. The cleared area bordered by stones might have been the outline of a water collection point or pool. The construction technique and location suggest that it was part of the same channel/pool system as sites N316 and N321 nearby.  ',28.0750570169998,35.177560989,'Site',0,NULL,NULL,NULL),(3,NULL,'N00321','Qantarat Aynuna','قنطرة قناة عَيْنُونَا','2022-10-17 13:20:56.595000','2022-10-18 17:42:00.541000',1,1,'4ED20F7F-0460-47C7-8C33-B96F7E5DF38A','Late pre-Islamic/Islamic/Modern channel. The site, located in a low-lying area between Wadi Aynounah and the historical harbor at al-Khuraybah, consists of a linear channel that runs north to south for approximately 125 m. The channel is 1 m wide on average along its length. It has a rock and concretion mixture foundation and a sandstone base and walls. There is no evidence that the channel was covered. There is a small path that bisected the feature near its preserved midpoint. Part of the same channel/pool system as sites N316 and N320 nearby, although it may have been reworked in the modern period based on the different style of construction evidence along part of its length.; ',28.077201,35.177896,'Site',0,NULL,NULL,NULL),(4,'NAS55-2','N00328','Aynuna','لوكِي كٌومي ','2022-10-17 13:20:58.033000','2022-10-18 17:42:11.832000',1,1,'5AAF50EB-4D96-4577-9C7B-CD262FF30F32','Nabataean and Roman settlement. The settlement, located on multiple terraces northeast of site N327, consists of a walled town or fortress with the remains of 80+ structures. The walls are preserved to an average of 1.5 m in height. There were considerable artifacts found scattered throughout the site including ceramics and lithics. Several of the ceramics were identified as Nabataean. On the northern boundary of the site there is a wall that may have been part of a tower or fortification. The site was previously surveyed by a joint Saudi and Polish team who labeled the site ‘Upper Aynuna’. Part of the Nabataean settlement system in Wadi Aynounah (with sites N323 and N327).',28.089352,35.185602,'Site',0,NULL,NULL,NULL),(5,'NAS55-3','N00329','Aynuna','لوكِي كٌومي ','2022-10-17 13:20:59.369000','2022-10-18 17:42:25.791000',1,1,'CC8610D1-214C-4525-BEDC-2E483E48E089','Cemetery of unknown date. The cemetery, located on a plateau on top of a cliff, consists of a stone scatter indicating the presence of undisturbed shaft tombs. There are no structures on top of the hill, however, the area is similar to several of the looted cemeteries nearby and there are several cairn structures on a lower terrace on the southern cliff face. Possibly part of a group of Nabataean cemeteries located to the northwest of the Nabataean settlements in Wadi Aynounah (N329-N334).; ',28.089992,35.183237,'Site',0,NULL,NULL,NULL),(6,NULL,'N00330','Aynuna','لوكِي كٌومي ','2022-10-17 13:52:24.949000','2022-10-18 17:42:37.924000',1,1,'0B620568-FB75-4331-868A-8563AA571924','Nabataean cemetery. The cemetery, located on a small plateau, consists of three shaft tombs. Tomb 1, which has been looted, is oriented east to west and descends approximately 4 m into the bedrock. Spoil piles with stones, sediment, and human remains were found adjacent to Tomb 1. Tombs 2 and 3 are located on the southern edge of the site surrounded by rocks. A block with a roughly chiseled Nabataean design and a fragment of a channel were found near Tomb 3. Part of a group of Nabataean cemeteries located to the northwest of the Nabataean settlements in Wadi Aynounah (N329-N334).',28.090908,35.182105,'Site',0,NULL,NULL,NULL),(7,'NAS55-4','N00331','Aynuna','لوكِي كٌومي ','2022-10-17 13:52:26.424000','2022-10-18 17:42:48.759000',1,1,'156CA79C-27E7-400C-A1C1-F918512198A6','Nabataean cemetery. The cemetery, located on top of a south facing hilltop, consists of multiple shaft tombs that are highly disturbed and, in some cases, completely looted. Four rectangular tombs, oriented east to west and cut 3 to 4 m into the bedrock, were disturbed and left open. Tomb 4 is centrally located and is surrounded by a small wall of rock preserved to 40 cm in height. Large mounds of dirt containing human remains were found adjacent to the tombs. Part of a group of Nabataean cemeteries located to the northwest of the Nabataean settlements in Wadi Aynounah (N329-N334).',28.091231,35.179979,'Site',0,NULL,NULL,NULL),(8,NULL,'N00332','Aynounah','لوكِي كٌومي ','2022-10-17 13:52:33.046000','2022-10-18 17:43:08.283000',1,1,'D804D2E9-1C30-442B-984B-C502C1955EB8','Nabataean cemetery. The cemetery, located on a plateau, consists of a concentration of 10 shaft tombs that show evidence for being looted. Most of the tombs descend approximately 8 m into the bedrock, measure 1.5 m by 2 m, and are oriented east to west. Human remains and ceramics were scattered around the tombs and a high concentration of ceramics was found in the north of the site. The ceramics were fragmentary and red in color, possibly indicating a Nabataean date. Part of a group of Nabataean cemeteries located to the northwest of the Nabataean settlements in Wadi Aynounah (N329-N334).',28.091697,35.180255,'Site',0,NULL,NULL,NULL),(9,NULL,'N00333','Aynounah','لوكِي كٌومي; ','2022-10-17 13:52:44.391000','2022-10-18 17:43:21.934000',1,1,'C8F0C143-59A0-4FCE-B498-AF044F651213','Nabataean cemetery. The cemetery, located on an elevated plateau, consists to 10 disturbed shaft tombs and several additional exploratory looter pits. The shafts descend approximately 7 m into the bedrock and have large, flat stones placed across the top as capstones. Spoil heaps containing human remains were found adjacent to many of the tombs. Assorted non-diagnostic ceramics and human remains were observed throughout the site. Part of a group of Nabataean cemeteries located to the northwest of the Nabataean settlements in Wadi Aynounah (N329-N334).',28.092323,35.180453,'Site',0,NULL,NULL,NULL),(10,NULL,'N00334','Aynounah','وكِي كٌومي','2022-10-17 13:52:49.885000','2022-10-18 17:43:39.123000',1,1,'9961F3E2-31AE-49F0-9D59-4BB8C0EB7DDC','Nabataean cemetery. The cemetery, located within a small valley between two ridges with a cliff face due south, consists of 5 looted shaft tombs with adjacent spoil heaps. The shafts descend approximately 3 to 5 m into the bedrock and are oriented east to west. Assorted non-diagnostic ceramics and human remains were observed throughout the site. Part of a group of Nabataean cemeteries located to the northwest of the Nabataean settlements in Wadi Aynounah (N329-N334). ',28.0924,35.181702,'Site',0,NULL,NULL,NULL),(11,NULL,'N00370','Al-Muwaylih','الُموَيْلح - الحي التراثي ','2022-10-17 14:10:15.011000','2022-10-18 17:43:50.003000',1,1,'71541F6F-A756-4AF8-8B3E-B0097D548707','Building from Ottoman or modern period. The structure was built of limestone and coral blocks. Three of the walls remain partially intact, but the building is generally in ruins, with additional modern building materials covering much of the site. The building originally contained multiple rooms. The site is part of several buildings situated within the heritage quarter of al-Muwaylih, north and west of the restored Ottoman fortress (N00369- N00382).',27.683058,35.476693,'Site',0,NULL,NULL,NULL),(12,NULL,'N00371','Al-Muwaylih','الُموَيْلح - الحي التراثي ','2022-10-17 14:12:29.637000','2022-10-18 17:44:03.864000',1,1,'1CFBB60B-D9BE-44AB-8CD7-742700C9C89F','Building from Ottoman or modern period. The site consists of a ruined rectangular structure originally comprised of two rooms. A single wall still stands to approximately 2 m in height. The structure was built of stone. Local construction materials from the fort conservation work can be found at the site. A single body sherd of an amphora was also found at the site. The site is part of several buildings situated within the heritage quarter of al-Muwaylih, north and west of the restored Ottoman fortress (N00369- N00382).',27.683031,35.477065,'Site',0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-18 21:25:54
