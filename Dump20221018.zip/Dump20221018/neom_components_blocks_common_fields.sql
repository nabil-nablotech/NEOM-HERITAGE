-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_blocks_common_fields`
--

DROP TABLE IF EXISTS `components_blocks_common_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_blocks_common_fields` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `file_size` varchar(255) DEFAULT NULL,
  `storage` varchar(255) DEFAULT NULL,
  `make` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `depth` varchar(255) DEFAULT NULL,
  `dimension` varchar(255) DEFAULT NULL,
  `created` date DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_blocks_common_fields`
--

LOCK TABLES `components_blocks_common_fields` WRITE;
/*!40000 ALTER TABLE `components_blocks_common_fields` DISABLE KEYS */;
INSERT INTO `components_blocks_common_fields` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'190664','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(3,'151913','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(4,'135752','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(5,'186129','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-07 00:00:00.000000'),(6,'169950','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(7,'164777','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(8,'161335','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-07 00:00:00.000000'),(9,'164021','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(10,'165190','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(11,'170903','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-13 00:00:00.000000'),(12,'201425','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-07 00:00:00.000000'),(13,'203099','Embedded',NULL,NULL,'144 x 144 dpi','1196 x 1154',NULL,'2022-09-07 00:00:00.000000'),(14,'4808723','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(15,'4976648','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(16,'5039358','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(17,'4582205','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(18,'4468896','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(19,'4634729','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000'),(20,'4554918','Embedded','Apple','iPad','72 x 72 dpi','3264 x 2448','2022-07-11','2022-09-13 00:00:00.000000');
/*!40000 ALTER TABLE `components_blocks_common_fields` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-18 20:01:08
