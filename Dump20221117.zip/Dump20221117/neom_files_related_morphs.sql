-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `files_related_morphs`
--

DROP TABLE IF EXISTS `files_related_morphs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files_related_morphs` (
  `file_id` int unsigned DEFAULT NULL,
  `related_id` int unsigned DEFAULT NULL,
  `related_type` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `order` int unsigned DEFAULT NULL,
  KEY `files_related_morphs_fk` (`file_id`),
  CONSTRAINT `files_related_morphs_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files_related_morphs`
--

LOCK TABLES `files_related_morphs` WRITE;
/*!40000 ALTER TABLE `files_related_morphs` DISABLE KEYS */;
INSERT INTO `files_related_morphs` VALUES (3,1,'api::login.login','image',1),(2,2,'shared.logo','image',1),(2,1,'shared.logo','image',1),(3,1,'api::login.login','backgroundImage',1),(140,118,'api::media.media','object',1),(47,16,'api::media.media','object',1),(35,17,'api::media.media','object',1),(30,18,'api::media.media','object',1),(42,19,'api::media.media','object',1),(37,14,'api::media.media','object',1),(24,15,'api::media.media','object',1),(49,20,'api::media.media','object',1),(43,21,'api::media.media','object',1),(19,22,'api::media.media','object',1),(45,23,'api::media.media','object',1),(32,24,'api::media.media','object',1),(11,25,'api::media.media','object',1),(28,26,'api::media.media','object',1),(21,27,'api::media.media','object',1),(44,28,'api::media.media','object',1),(46,29,'api::media.media','object',1),(26,30,'api::media.media','object',1),(27,31,'api::media.media','object',1),(16,32,'api::media.media','object',1),(15,33,'api::media.media','object',1),(36,34,'api::media.media','object',1),(23,35,'api::media.media','object',1),(18,36,'api::media.media','object',1),(39,37,'api::media.media','object',1),(7,38,'api::media.media','object',1),(10,39,'api::media.media','object',1),(12,40,'api::media.media','object',1),(33,41,'api::media.media','object',1),(22,42,'api::media.media','object',1),(29,43,'api::media.media','object',1),(41,44,'api::media.media','object',1),(40,46,'api::media.media','object',1),(13,47,'api::media.media','object',1),(6,48,'api::media.media','object',1),(9,49,'api::media.media','object',1),(8,50,'api::media.media','object',1),(5,51,'api::media.media','object',1),(4,52,'api::media.media','object',1),(34,53,'api::media.media','object',1),(137,54,'api::media.media','object',1),(69,55,'api::media.media','object',1),(58,56,'api::media.media','object',1),(94,57,'api::media.media','object',1),(77,58,'api::media.media','object',1),(59,59,'api::media.media','object',1),(113,60,'api::media.media','object',1),(136,61,'api::media.media','object',1),(107,62,'api::media.media','object',1),(38,63,'api::media.media','object',1),(25,64,'api::media.media','object',1),(54,65,'api::media.media','object',1),(51,66,'api::media.media','object',1),(78,67,'api::media.media','object',1),(75,68,'api::media.media','object',1),(66,69,'api::media.media','object',1),(70,70,'api::media.media','object',1),(63,71,'api::media.media','object',1),(81,72,'api::media.media','object',1),(83,73,'api::media.media','object',1),(79,74,'api::media.media','object',1),(90,75,'api::media.media','object',1),(97,76,'api::media.media','object',1),(114,77,'api::media.media','object',1),(93,78,'api::media.media','object',1),(86,79,'api::media.media','object',1),(76,80,'api::media.media','object',1),(80,81,'api::media.media','object',1),(65,82,'api::media.media','object',1),(99,84,'api::media.media','object',1),(96,85,'api::media.media','object',1),(92,86,'api::media.media','object',1),(60,87,'api::media.media','object',1),(17,88,'api::media.media','object',1),(14,89,'api::media.media','object',1),(53,90,'api::media.media','object',1),(50,91,'api::media.media','object',1),(62,92,'api::media.media','object',1),(82,93,'api::media.media','object',1),(57,94,'api::media.media','object',1),(88,95,'api::media.media','object',1),(67,96,'api::media.media','object',1),(84,97,'api::media.media','object',1),(74,98,'api::media.media','object',1),(85,99,'api::media.media','object',1),(64,100,'api::media.media','object',1),(55,101,'api::media.media','object',1),(72,102,'api::media.media','object',1),(89,103,'api::media.media','object',1),(118,104,'api::media.media','object',1),(123,105,'api::media.media','object',1),(143,106,'api::media.media','object',1),(116,107,'api::media.media','object',1),(126,108,'api::media.media','object',1),(91,109,'api::media.media','object',1),(110,110,'api::media.media','object',1),(133,111,'api::media.media','object',1),(112,112,'api::media.media','object',1),(124,113,'api::media.media','object',1),(105,114,'api::media.media','object',1),(115,115,'api::media.media','object',1),(132,116,'api::media.media','object',1),(104,117,'api::media.media','object',1),(120,119,'api::media.media','object',1),(125,120,'api::media.media','object',1),(68,121,'api::media.media','object',1),(100,123,'api::media.media','object',1),(129,124,'api::media.media','object',1),(130,125,'api::media.media','object',1),(102,126,'api::media.media','object',1),(117,127,'api::media.media','object',1),(142,128,'api::media.media','object',1),(119,129,'api::media.media','object',1),(139,131,'api::media.media','object',1),(48,132,'api::media.media','object',1),(52,133,'api::media.media','object',1),(71,134,'api::media.media','object',1),(61,135,'api::media.media','object',1),(56,136,'api::media.media','object',1),(121,137,'api::media.media','object',1),(111,138,'api::media.media','object',1),(138,140,'api::media.media','object',1),(109,141,'api::media.media','object',1),(144,142,'api::media.media','object',1),(152,156,'api::media.media','object',1),(155,144,'api::media.media','object',1),(157,1,'api::media.media','object',1),(73,139,'api::media.media','object',1),(158,159,'api::media.media','object',1),(159,143,'api::media.media','object',1),(160,160,'api::media.media','object',1),(162,161,'api::media.media','object',1),(163,162,'api::media.media','object',1),(87,122,'api::media.media','object',1),(164,163,'api::media.media','object',1),(98,2,'api::media.media','object',1),(106,130,'api::media.media','object',1),(122,83,'api::media.media','object',1),(31,45,'api::media.media','object',1),(131,3,'api::media.media','object',1),(101,4,'api::media.media','object',1),(108,5,'api::media.media','object',1),(128,7,'api::media.media','object',1),(103,8,'api::media.media','object',1),(135,9,'api::media.media','object',1),(95,11,'api::media.media','object',1),(141,12,'api::media.media','object',1),(20,13,'api::media.media','object',1),(127,6,'api::media.media','object',1),(134,10,'api::media.media','object',1);
/*!40000 ALTER TABLE `files_related_morphs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-17 11:58:34
