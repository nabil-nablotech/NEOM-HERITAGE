-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_blocks_locales`
--

DROP TABLE IF EXISTS `components_blocks_locales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_blocks_locales` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `value` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_blocks_locales`
--

LOCK TABLES `components_blocks_locales` WRITE;
/*!40000 ALTER TABLE `components_blocks_locales` DISABLE KEYS */;
INSERT INTO `components_blocks_locales` VALUES (1,'Email'),(2,'البريد الإلكتروني'),(3,'Password'),(4,'كلمة المرور'),(5,'Sign in'),(6,'تسجيل الدخول'),(7,'Anchorage'),(8,'مرسى'),(9,'Artifact Scatter'),(10,'مبعثر قطعة أثرية'),(11,'Battlefield'),(12,'ساحة المعركة'),(13,'Inscription'),(14,'نقش'),(15,'Rock art'),(16,'الفن الصخري'),(17,'Channel/Canal'),(18,'القناة / القناة'),(19,'Cleared area'),(20,'منطقة تم تطهيرها'),(21,'Settlement'),(22,'مستعمرة'),(23,'cemetery'),(24,'مقبرة'),(25,'Building'),(26,'مبنى'),(27,'1.Minor'),(28,'1. طفيفة'),(29,'3.National'),(30,'3. الوطنية'),(31,'2.Limited'),(32,'2.محدودة'),(33,'4.International'),(34,'4.الدولية'),(35,'3.Fair'),(36,'3. عادل'),(37,'2.Poor'),(38,'2. ضعيف'),(39,'1.Very Bad'),(40,'1. سيئ جدا'),(41,'0.No further action required'),(42,'0- لا يلزم اتخاذ أي إجراء آخر'),(43,'1.Protected'),(44,'1. محمي'),(45,'2.Protected and rehabilitated'),(46,'2- محميّة ومُؤَهَّلَة'),(47,'3.Identifiable Threat'),(48,'3 - التهديد الذي يمكن تحديده'),(49,'2.Possible Threat'),(50,'2- التهديد المحتمل'),(51,'4.Actively Damaged'),(52,'4.تلف بشكل نشط'),(53,'1.Local'),(54,'1. محلي'),(55,'Modern'),(56,'عصري'),(57,'Islamic'),(58,'إسلامي'),(59,'Early'),(60,'مبكر'),(61,'Pre-Islamic'),(62,'ما قبل الإسلام'),(63,'Multi-Period'),(64,'متعدد الفترات'),(65,'Late'),(66,'متأخر'),(67,'Nabatean'),(68,'نبطي'),(69,'Roman'),(70,'رومان'),(71,'Unknown'),(72,'مجهول'),(73,'Ottoman'),(74,'العثماني'),(75,'Observed'),(76,'لاحظ'),(77,'Observed and photographed'),(78,'تمت ملاحظتها وتصويرها'),(79,'Collected'),(80,'جمعت'),(81,'Not observed'),(82,'لم يلاحظ'),(83,'Field-based'),(84,'ميداني قائم'),(85,'Remote sensing'),(86,'الاستشعار عن بعد'),(87,'Remote sensing verified in the field'),(88,'تم التحقق من الاستشعار عن بعد في الميدان'),(89,'Virtual'),(90,'افتراضية'),(91,'Boston dynamics robot'),(92,'روبوت بوسطن ديناميكس'),(93,'4.Good'),(94,'4. جيد'),(95,'5.Exceptional'),(96,'5. استثنائي'),(97,'0.Negligible'),(98,'0- مهمل'),(99,'1.No Threat'),(100,'1. لا تهديد'),(101,'4.International'),(102,'4.الدولية'),(103,'0.Negligible'),(104,'0- مهمل'),(105,'3.National'),(106,'3. الوطنية'),(107,'2.Limited'),(108,'2.محدودة'),(109,'Artifacts'),(110,'الآثار'),(111,'Detail'),(112,'التفاصيل'),(113,'Disturbance Overview'),(114,'نظرة عامة على الإزعاج'),(115,'Exclusion Overview'),(116,'نظرة عامة على الاستبعاد'),(117,'Feature Detail'),(118,'تفاصيل الميزة'),(119,'Feature Overview'),(120,'نظرة عامة على الميزة'),(121,'Location Map'),(122,'خريطة الموقع'),(123,'Overview'),(124,'ملخص'),(125,'Site Overview'),(126,'نظرة عامة على الموقع'),(127,'Sketch Map'),(128,'رسم الخريطة'),(129,'Paleolithic'),(130,'العصر الحجري القديم'),(131,'Lower'),(132,'أدنى'),(133,'Middle'),(134,'وسط'),(135,'Upper'),(136,'العلوي'),(137,'Pre-Pottery Neolithic'),(138,'العصر الحجري الحديث قبل الفخار'),(139,'Bronze Age'),(140,'العصر البرونزي'),(141,'Iron Age'),(142,'العصر الحديدي'),(143,'Chalcolithic'),(144,'نحاسي'),(145,'Midianite'),(146,'ميديانيت'),(147,'Lihyanite'),(148,'اللهيانيت'),(149,'Epi-Paleolithic'),(150,'Epi-Paleolithic'),(151,'Neolithic'),(152,'العصر الحجري الحديث'),(153,'Bridge'),(154,'كوبري'),(155,'دفن'),(156,'Cairn'),(157,'ركام من حجارة'),(158,'Ring cairn'),(159,'خاتم كايرن'),(160,'Campsite'),(161,'المخيم'),(162,'Cave'),(163,'كهف'),(164,'Cist grave/Dolmen'),(165,'قبض القبر / دولمن'),(166,'Cistern'),(167,'صهريج'),(168,'District'),(169,'يصرف'),(170,'Farm'),(171,'مزرعة'),(172,'Fort/fortress/castle'),(173,'حصن / حصن / قلعة'),(174,'Kiln/forge/furnace'),(175,'فرن / حدادة / فرن'),(176,'Kite'),(177,'طائرة ورقية'),(178,'Market'),(179,'سوق'),(180,'Mine'),(181,'مِلكِي'),(182,'Mustatil'),(183,'موستاتيل'),(184,'Natural site'),(185,'موقع طبيعي'),(186,'Observational point'),(187,'نقطة المراقبة'),(188,'Pendant burial'),(189,'دفن قلادة'),(190,'Aircraft Crash Site'),(191,'موقع تحطم الطائرات'),(192,'Platform'),(193,'برنامج'),(194,'Port'),(195,'ميناء'),(196,'Railway'),(197,'سكة حديدية'),(198,'Railway station'),(199,'محطة قطار'),(200,'Road/Path/Trackway'),(201,'الطريق / المسار / المسار'),(202,'Road station'),(203,'محطة الطريق'),(204,'Shaft/tunnel'),(205,'رمح / نفق'),(206,'Burial'),(207,'Shell midden'),(208,'شل ميدين'),(209,'Shipwreck'),(210,'حطام سفينة'),(211,'Stone circle'),(212,'الدائرة الحجرية'),(213,'Stone structure'),(214,'هيكل الحجر'),(215,'Temple/sanctuary/shrine'),(216,'معبد / مزار / ضريح'),(217,'Tomb'),(218,'قبر'),(219,'Tower'),(220,'برج'),(221,'Upright stone'),(222,'تستقيم الحجر'),(223,'Wall'),(224,'حائط'),(225,'Water source'),(226,'مصدر المياه'),(227,'Well'),(228,'نحن سوف'),(229,'Caravanserai'),(230,'كارافانسيراي'),(231,'Rock cut chamber'),(232,'غرفة قطع الصخور'),(233,'Islamic Burial'),(234,'دفن إسلامي'),(235,'Dam/Check dam'),(236,'السد / فحص السد'),(237,'Find Spot'),(238,'البحث عن بقعة'),(239,'Firepit/Hearth/Mudhaby'),(240,'موقد/ النار / مذهب'),(241,'Qanat'),(242,'قناة'),(243,'Slag Scatter/Heap'),(244,'نثر الخبث / الكومة'),(245,'Terrace'),(246,'مصطبة'),(247,'Trilith'),(248,'تريليث'),(249,'Tumulus'),(250,'تومولوس'),(251,'Grove/garden/orchard'),(252,'بستان / حديقة / بستان'),(253,'Other'),(254,'آخر');
/*!40000 ALTER TABLE `components_blocks_locales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-17 11:58:16
