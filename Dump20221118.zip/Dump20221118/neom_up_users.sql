-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `up_users`
--

DROP TABLE IF EXISTS `up_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `up_users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `reset_password_token` varchar(255) DEFAULT NULL,
  `confirmation_token` varchar(255) DEFAULT NULL,
  `confirmed` tinyint(1) DEFAULT NULL,
  `blocked` tinyint(1) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `recovery_token` longtext,
  PRIMARY KEY (`id`),
  KEY `up_users_created_by_id_fk` (`created_by_id`),
  KEY `up_users_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `up_users_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `up_users_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_users`
--

LOCK TABLES `up_users` WRITE;
/*!40000 ALTER TABLE `up_users` DISABLE KEYS */;
INSERT INTO `up_users` VALUES (5,'abhi','abhi@mail.com','local','$2a$10$/DWGXMCqcWe0l70RIG6sDuyFka7P1b/pAn9SjGe9yZ9.i3Bcc23lu',NULL,NULL,1,0,'2022-10-14 15:53:35.764000','2022-11-15 16:28:14.003000',1,1,'Abhi','Joy','null'),(6,'foo','hey@mail.com','local','$2a$10$gZ4EsLrA8UUSDmm/LcTTUO9mw7XfJjh3z6Cgr/Ds3N2PHMm.KZPg6',NULL,NULL,0,1,'2022-10-14 22:47:10.123000','2022-10-25 12:32:52.818000',NULL,NULL,'hey','by','JTdCJTIyaWRlbnRpZmllciUyMiUzQSUyMmhleSU0MG1haWwuY29tJTIyJTJDJTIyaWQlMjIlM0E2JTJDJTIyZXhwJTIyJTNBJTIyMjAyMi0xMS0xM1QxNyUzQTE3JTNBMTAuMTQ1WiUyMiU3RA=='),(7,'zonty','zonty@mail.com','local','$2a$10$7pDc2.DrG2GbWGQrFYPvvObdcE2QyziuBe.FGxceVIP6avBxsJ/Ny',NULL,NULL,1,0,'2022-10-25 12:30:35.577000','2022-11-08 15:53:05.159000',1,1,'Zonty','Rodes','null'),(8,'diksha','diksha@mail.com','local','$2a$10$GmMWhJWd5G4LZwAgMZ1GfeGR9I0C4cS0PvFJeFLdOXLakJS9rImE6',NULL,NULL,1,0,'2022-11-03 13:44:41.805000','2022-11-03 13:44:41.805000',1,1,'Diksha','Deep','null'),(9,'siddhesh','sutar@mail.com','local','$2a$10$kTI8.J3ZPipQdULYSOrqaumszmMeK6UJIr8MBz7V554t0s8Ey4Q26',NULL,NULL,1,0,'2022-11-03 13:45:30.192000','2022-11-03 13:45:30.192000',1,1,'Siddhesh','sutar','null');
/*!40000 ALTER TABLE `up_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 20:15:32
