-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `field_options_translation_links`
--

DROP TABLE IF EXISTS `field_options_translation_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_options_translation_links` (
  `field_option_id` int unsigned DEFAULT NULL,
  `translation_id` int unsigned DEFAULT NULL,
  KEY `field_options_translation_links_fk` (`field_option_id`),
  KEY `field_options_translation_links_inv_fk` (`translation_id`),
  CONSTRAINT `field_options_translation_links_fk` FOREIGN KEY (`field_option_id`) REFERENCES `field_options` (`id`) ON DELETE CASCADE,
  CONSTRAINT `field_options_translation_links_inv_fk` FOREIGN KEY (`translation_id`) REFERENCES `translations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_options_translation_links`
--

LOCK TABLES `field_options_translation_links` WRITE;
/*!40000 ALTER TABLE `field_options_translation_links` DISABLE KEYS */;
INSERT INTO `field_options_translation_links` VALUES (1,4),(2,5),(3,6),(4,7),(5,8),(6,9),(7,10),(8,11),(9,12),(10,13),(25,28),(26,29),(27,30),(28,31),(30,33),(31,34),(32,35),(33,36),(34,37),(35,38),(36,39),(37,40),(38,41),(39,42),(40,43),(41,44),(52,55),(53,56),(54,57),(55,58),(56,59),(60,63),(61,64),(59,62),(58,61),(57,60),(18,20),(17,19),(16,18),(44,47),(45,48),(24,23),(23,22),(22,21),(11,14),(51,52),(46,49),(49,53),(12,15),(14,17),(50,51),(13,16),(47,50),(20,25),(19,24),(21,26),(48,54),(15,27),(62,65),(63,66),(64,67),(65,68),(66,69),(67,70),(68,71),(69,72),(70,73),(71,74),(72,75),(73,76),(74,77),(75,78),(76,79),(77,80),(78,81),(79,82),(80,83),(81,84),(82,85),(83,86),(84,87),(85,126),(86,88),(87,89),(88,90),(89,91),(90,92),(91,93),(92,94),(93,95),(94,96),(95,97),(96,98),(97,99),(98,100),(99,101),(100,102),(101,103),(102,104),(103,105),(104,106),(105,107),(106,108),(107,109),(108,110),(109,111),(110,112),(111,113),(112,114),(113,115),(114,116),(115,117),(116,118),(117,119),(118,120),(119,121),(120,122),(121,123),(122,124),(123,125),(124,127);
/*!40000 ALTER TABLE `field_options_translation_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-29 22:08:07
