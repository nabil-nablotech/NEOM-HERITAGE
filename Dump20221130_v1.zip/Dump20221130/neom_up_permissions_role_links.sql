-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `up_permissions_role_links`
--

DROP TABLE IF EXISTS `up_permissions_role_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `up_permissions_role_links` (
  `permission_id` int unsigned DEFAULT NULL,
  `role_id` int unsigned DEFAULT NULL,
  KEY `up_permissions_role_links_fk` (`permission_id`),
  KEY `up_permissions_role_links_inv_fk` (`role_id`),
  CONSTRAINT `up_permissions_role_links_fk` FOREIGN KEY (`permission_id`) REFERENCES `up_permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `up_permissions_role_links_inv_fk` FOREIGN KEY (`role_id`) REFERENCES `up_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_permissions_role_links`
--

LOCK TABLES `up_permissions_role_links` WRITE;
/*!40000 ALTER TABLE `up_permissions_role_links` DISABLE KEYS */;
INSERT INTO `up_permissions_role_links` VALUES (1,1),(10,2),(15,3),(17,1),(16,1),(18,1),(20,1),(19,1),(21,1),(22,1),(23,1),(25,1),(26,1),(27,1),(28,4),(29,1),(30,1),(47,2),(56,2),(57,2),(58,2),(59,2),(60,2),(61,2),(67,2),(69,2),(76,2),(79,1),(80,1),(83,1),(84,1),(87,1),(91,1),(92,1),(88,1),(95,1),(96,1),(99,3),(100,3),(101,3),(102,3),(103,3),(105,3),(104,3),(106,3),(107,3),(112,3),(113,3),(114,3),(115,3),(108,3),(109,3),(110,3),(111,3),(118,3),(116,3),(117,3),(120,3),(123,2),(122,2),(126,1),(127,1),(133,1),(135,1),(140,1),(138,1),(141,1),(147,1),(148,1),(152,1),(153,1),(157,1),(163,1),(164,1),(168,1),(171,1),(180,1),(181,1),(183,1),(182,1),(184,1),(187,3),(188,3),(192,3),(193,3),(194,3),(195,3),(196,3),(199,3),(200,3),(197,3),(198,3),(204,3),(201,3),(202,3),(203,3),(205,3),(206,3),(207,3),(209,1),(210,1),(214,3),(216,3),(215,3),(217,3),(218,2),(220,3),(221,3),(222,3),(223,3),(226,3),(227,3),(229,3),(228,3),(230,3),(232,5),(231,5),(236,5),(235,5),(237,5),(238,5),(239,5),(240,5),(241,5),(242,5),(243,5),(244,5),(247,5),(248,5),(254,5),(257,5),(253,5),(255,5),(256,5),(258,5),(259,5),(262,5),(263,5),(264,5),(265,5),(266,5),(267,5),(268,5),(269,5),(270,5),(271,5),(272,5),(273,5),(274,5),(275,5),(276,5),(277,5),(278,5),(279,5),(280,5),(281,5),(282,5),(283,5),(284,5),(285,5),(286,4),(287,4),(288,4),(289,4),(290,4),(293,4),(291,4),(292,4),(294,4),(295,4),(296,4),(297,4),(298,4),(300,4),(299,4),(301,4),(303,4),(302,4),(305,4),(304,4),(307,4),(308,4),(309,4),(306,4),(310,4),(311,4),(312,4),(313,4),(314,4),(315,4),(316,4),(317,4),(318,4),(319,4),(320,4),(321,4),(322,4),(323,4),(329,1),(326,1),(327,1),(328,1),(333,1),(330,1),(332,1),(331,1),(334,1),(335,1),(338,3),(339,3),(340,3),(359,3),(360,3),(361,3),(363,3),(365,3),(364,3),(366,3),(367,3),(368,3),(369,3),(370,3),(371,3),(372,3),(373,3),(374,3),(375,3),(376,3),(377,3),(378,3),(380,5),(381,5),(382,5),(383,5),(384,5),(391,5),(385,5),(386,5),(389,5),(388,5),(387,5),(390,5),(395,5),(396,5),(397,5),(398,5),(399,5),(400,5),(393,5),(394,5),(403,5),(404,5),(407,5),(402,5),(411,5),(412,5),(413,5),(414,5),(408,5),(409,5),(410,5),(415,3),(416,3),(420,1),(421,1),(423,1),(422,1),(424,1),(428,1),(426,1),(431,1),(430,1),(429,1),(433,1),(434,1),(435,1),(439,5),(477,5),(475,5),(478,5),(488,4),(489,4),(487,4),(490,4),(491,4),(493,4),(492,4),(494,4),(495,3),(497,3),(496,3),(498,2),(499,3),(500,4),(501,5),(502,5),(503,5),(504,5),(505,3),(506,3),(507,4),(508,4),(509,4),(510,4),(511,1),(512,1);
/*!40000 ALTER TABLE `up_permissions_role_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-30 12:15:36
