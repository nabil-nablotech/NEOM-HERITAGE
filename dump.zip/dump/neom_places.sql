-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `places` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `previous_number` varchar(255) DEFAULT NULL,
  `place_number` varchar(255) DEFAULT NULL,
  `place_name_english` varchar(255) DEFAULT NULL,
  `place_name_arabic` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `unique_id` varchar(255) DEFAULT NULL,
  `site_description` longtext,
  `period` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `place_ui_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `places_created_by_id_fk` (`created_by_id`),
  KEY `places_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `places_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `places_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `places`
--

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (2,NULL,'N00282','Qisarah Valley South side ','وادي قصارة - الطرف الجنوبي','2022-10-13 20:07:26.441000','2022-10-13 21:39:19.872000','2022-10-13 21:39:19.859000',1,1,'0B3D41DD-707D-49E0-9C24-40D7F9325D95','Pre-Islamic, Islamic, and modern inscription/rock art site. The site, located at the base of a cliff face in a wadi system, consists of an aeolian sandstone formation, approximately 2.5 to 3 m in height and 12 to 15 m in length. Inscriptions in Arabic and English are present on the north face of the sandstone formation and continue down onto a small flat area at the base. Arabic numerals, several written as dates, are also inscribed in this area. Additional carvings include hands, feet, possible animals, and linear markings. There are several deeper linear grooves running vertically north to south along the face of the sandstone formation with evidence of tire tracks. Possibly related to site N283 located on the opposite side of the wadi.','Modern; Islamic, Early; Pre-Islamic; Multi-Period',28.453,34.80304,'Site',0,NULL,NULL);
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-13 21:41:46
