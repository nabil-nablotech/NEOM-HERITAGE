-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `up_permissions`
--

DROP TABLE IF EXISTS `up_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `up_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `up_permissions_created_by_id_fk` (`created_by_id`),
  KEY `up_permissions_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `up_permissions_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `up_permissions_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_permissions`
--

LOCK TABLES `up_permissions` WRITE;
/*!40000 ALTER TABLE `up_permissions` DISABLE KEYS */;
INSERT INTO `up_permissions` VALUES (1,'plugin::users-permissions.user.me','2022-09-28 12:59:00.407000','2022-09-28 12:59:00.407000',NULL,NULL),(10,'api::login.login.find','2022-10-03 14:47:40.314000','2022-10-03 14:47:40.314000',NULL,NULL),(15,'api::login.login.find','2022-10-04 15:04:07.256000','2022-10-04 15:04:07.256000',NULL,NULL),(16,'plugin::users-permissions.user.create','2022-10-04 15:05:33.988000','2022-10-04 15:05:33.988000',NULL,NULL),(17,'plugin::users-permissions.user.update','2022-10-04 15:05:33.988000','2022-10-04 15:05:33.988000',NULL,NULL),(18,'plugin::users-permissions.user.find','2022-10-04 15:05:33.988000','2022-10-04 15:05:33.988000',NULL,NULL),(19,'plugin::users-permissions.user.findOne','2022-10-04 15:05:33.989000','2022-10-04 15:05:33.989000',NULL,NULL),(20,'plugin::users-permissions.user.count','2022-10-04 15:05:33.989000','2022-10-04 15:05:33.989000',NULL,NULL),(21,'plugin::users-permissions.permissions.getPermissions','2022-10-04 15:05:33.989000','2022-10-04 15:05:33.989000',NULL,NULL),(22,'plugin::upload.content-api.find','2022-10-04 15:06:26.588000','2022-10-04 15:06:26.588000',NULL,NULL),(23,'plugin::upload.content-api.findOne','2022-10-04 15:06:26.588000','2022-10-04 15:06:26.588000',NULL,NULL),(24,'plugin::upload.content-api.upload','2022-10-04 15:06:26.588000','2022-10-04 15:06:26.588000',NULL,NULL),(25,'api::user-page.user-page.find','2022-10-04 16:37:57.964000','2022-10-04 16:37:57.964000',NULL,NULL),(26,'api::add-user.add-user.find','2022-10-04 18:10:09.201000','2022-10-04 18:10:09.201000',NULL,NULL),(27,'api::home-page.home-page.find','2022-10-05 11:28:52.213000','2022-10-05 11:28:52.213000',NULL,NULL),(28,'api::home-page.home-page.find','2022-10-05 11:46:01.563000','2022-10-05 11:46:01.563000',NULL,NULL),(29,'plugin::users-permissions.role.findOne','2022-10-06 12:40:12.197000','2022-10-06 12:40:12.197000',NULL,NULL),(30,'plugin::users-permissions.role.find','2022-10-06 12:40:12.197000','2022-10-06 12:40:12.197000',NULL,NULL),(47,'plugin::users-permissions.auth.callback','2022-10-10 17:55:11.612000','2022-10-10 17:55:11.612000',NULL,NULL);
/*!40000 ALTER TABLE `up_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-13 19:06:11
