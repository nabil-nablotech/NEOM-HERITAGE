-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medias_components`
--

DROP TABLE IF EXISTS `medias_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medias_components` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity_id` int unsigned DEFAULT NULL,
  `component_id` int unsigned DEFAULT NULL,
  `component_type` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `order` int unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `medias_field_index` (`field`),
  KEY `medias_component_type_index` (`component_type`),
  KEY `medias_entity_fk` (`entity_id`),
  CONSTRAINT `medias_entity_fk` FOREIGN KEY (`entity_id`) REFERENCES `medias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=372 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medias_components`
--

LOCK TABLES `medias_components` WRITE;
/*!40000 ALTER TABLE `medias_components` DISABLE KEYS */;
INSERT INTO `medias_components` VALUES (132,118,119,'blocks.common-fields','imageMetadata',1),(179,16,17,'blocks.common-fields','imageMetadata',1),(180,17,18,'blocks.common-fields','imageMetadata',1),(181,18,19,'blocks.common-fields','imageMetadata',1),(182,19,20,'blocks.common-fields','imageMetadata',1),(184,14,15,'blocks.common-fields','imageMetadata',1),(185,15,16,'blocks.common-fields','imageMetadata',1),(186,20,21,'blocks.common-fields','imageMetadata',1),(187,21,22,'blocks.common-fields','imageMetadata',1),(188,22,23,'blocks.common-fields','imageMetadata',1),(189,23,24,'blocks.common-fields','imageMetadata',1),(190,24,25,'blocks.common-fields','imageMetadata',1),(191,25,26,'blocks.common-fields','imageMetadata',1),(192,26,27,'blocks.common-fields','imageMetadata',1),(193,27,28,'blocks.common-fields','imageMetadata',1),(194,28,29,'blocks.common-fields','imageMetadata',1),(195,29,30,'blocks.common-fields','imageMetadata',1),(196,30,31,'blocks.common-fields','imageMetadata',1),(197,31,32,'blocks.common-fields','imageMetadata',1),(198,32,33,'blocks.common-fields','imageMetadata',1),(199,33,34,'blocks.common-fields','imageMetadata',1),(200,34,35,'blocks.common-fields','imageMetadata',1),(201,35,36,'blocks.common-fields','imageMetadata',1),(202,36,37,'blocks.common-fields','imageMetadata',1),(203,37,38,'blocks.common-fields','imageMetadata',1),(204,38,39,'blocks.common-fields','imageMetadata',1),(205,39,40,'blocks.common-fields','imageMetadata',1),(206,40,41,'blocks.common-fields','imageMetadata',1),(207,41,42,'blocks.common-fields','imageMetadata',1),(208,42,43,'blocks.common-fields','imageMetadata',1),(209,43,44,'blocks.common-fields','imageMetadata',1),(210,44,45,'blocks.common-fields','imageMetadata',1),(212,46,47,'blocks.common-fields','imageMetadata',1),(213,47,48,'blocks.common-fields','imageMetadata',1),(214,48,49,'blocks.common-fields','imageMetadata',1),(215,49,50,'blocks.common-fields','imageMetadata',1),(216,50,51,'blocks.common-fields','imageMetadata',1),(217,51,52,'blocks.common-fields','imageMetadata',1),(218,52,53,'blocks.common-fields','imageMetadata',1),(219,53,54,'blocks.common-fields','imageMetadata',1),(220,54,55,'blocks.common-fields','imageMetadata',1),(221,55,56,'blocks.common-fields','imageMetadata',1),(222,56,57,'blocks.common-fields','imageMetadata',1),(223,57,58,'blocks.common-fields','imageMetadata',1),(224,58,59,'blocks.common-fields','imageMetadata',1),(225,59,60,'blocks.common-fields','imageMetadata',1),(226,60,61,'blocks.common-fields','imageMetadata',1),(227,61,62,'blocks.common-fields','imageMetadata',1),(228,62,63,'blocks.common-fields','imageMetadata',1),(229,63,64,'blocks.common-fields','imageMetadata',1),(230,64,65,'blocks.common-fields','imageMetadata',1),(231,65,66,'blocks.common-fields','imageMetadata',1),(232,66,67,'blocks.common-fields','imageMetadata',1),(233,67,68,'blocks.common-fields','imageMetadata',1),(234,68,69,'blocks.common-fields','imageMetadata',1),(235,69,70,'blocks.common-fields','imageMetadata',1),(236,70,71,'blocks.common-fields','imageMetadata',1),(237,71,72,'blocks.common-fields','imageMetadata',1),(238,72,73,'blocks.common-fields','imageMetadata',1),(239,73,74,'blocks.common-fields','imageMetadata',1),(240,74,75,'blocks.common-fields','imageMetadata',1),(241,75,76,'blocks.common-fields','imageMetadata',1),(242,76,77,'blocks.common-fields','imageMetadata',1),(243,77,78,'blocks.common-fields','imageMetadata',1),(244,78,79,'blocks.common-fields','imageMetadata',1),(245,79,80,'blocks.common-fields','imageMetadata',1),(246,80,81,'blocks.common-fields','imageMetadata',1),(247,81,82,'blocks.common-fields','imageMetadata',1),(248,82,83,'blocks.common-fields','imageMetadata',1),(250,84,85,'blocks.common-fields','imageMetadata',1),(251,85,86,'blocks.common-fields','imageMetadata',1),(252,86,87,'blocks.common-fields','imageMetadata',1),(253,87,88,'blocks.common-fields','imageMetadata',1),(254,88,89,'blocks.common-fields','imageMetadata',1),(255,89,90,'blocks.common-fields','imageMetadata',1),(256,90,91,'blocks.common-fields','imageMetadata',1),(257,91,92,'blocks.common-fields','imageMetadata',1),(258,92,93,'blocks.common-fields','imageMetadata',1),(259,93,94,'blocks.common-fields','imageMetadata',1),(260,94,95,'blocks.common-fields','imageMetadata',1),(261,95,96,'blocks.common-fields','imageMetadata',1),(262,96,97,'blocks.common-fields','imageMetadata',1),(263,97,98,'blocks.common-fields','imageMetadata',1),(264,98,99,'blocks.common-fields','imageMetadata',1),(265,99,100,'blocks.common-fields','imageMetadata',1),(266,100,101,'blocks.common-fields','imageMetadata',1),(267,101,102,'blocks.common-fields','imageMetadata',1),(268,102,103,'blocks.common-fields','imageMetadata',1),(269,103,104,'blocks.common-fields','imageMetadata',1),(270,104,105,'blocks.common-fields','imageMetadata',1),(271,105,106,'blocks.common-fields','imageMetadata',1),(272,106,107,'blocks.common-fields','imageMetadata',1),(273,107,108,'blocks.common-fields','imageMetadata',1),(274,108,109,'blocks.common-fields','imageMetadata',1),(275,109,110,'blocks.common-fields','imageMetadata',1),(276,110,111,'blocks.common-fields','imageMetadata',1),(277,111,112,'blocks.common-fields','imageMetadata',1),(278,112,113,'blocks.common-fields','imageMetadata',1),(279,113,114,'blocks.common-fields','imageMetadata',1),(280,114,115,'blocks.common-fields','imageMetadata',1),(281,115,116,'blocks.common-fields','imageMetadata',1),(282,116,117,'blocks.common-fields','imageMetadata',1),(284,117,118,'blocks.common-fields','imageMetadata',1),(285,119,120,'blocks.common-fields','imageMetadata',1),(286,120,121,'blocks.common-fields','imageMetadata',1),(287,121,122,'blocks.common-fields','imageMetadata',1),(289,123,124,'blocks.common-fields','imageMetadata',1),(290,124,125,'blocks.common-fields','imageMetadata',1),(291,125,126,'blocks.common-fields','imageMetadata',1),(292,126,127,'blocks.common-fields','imageMetadata',1),(293,127,128,'blocks.common-fields','imageMetadata',1),(294,128,129,'blocks.common-fields','imageMetadata',1),(295,129,130,'blocks.common-fields','imageMetadata',1),(297,131,132,'blocks.common-fields','imageMetadata',1),(298,132,133,'blocks.common-fields','imageMetadata',1),(299,133,134,'blocks.common-fields','imageMetadata',1),(300,134,135,'blocks.common-fields','imageMetadata',1),(301,135,136,'blocks.common-fields','imageMetadata',1),(302,136,137,'blocks.common-fields','imageMetadata',1),(303,137,138,'blocks.common-fields','imageMetadata',1),(304,138,139,'blocks.common-fields','imageMetadata',1),(306,140,141,'blocks.common-fields','imageMetadata',1),(309,141,142,'blocks.common-fields','imageMetadata',1),(313,142,143,'blocks.common-fields','imageMetadata',1),(344,139,174,'blocks.common-fields','imageMetadata',1),(349,160,179,'blocks.common-fields','imageMetadata',1),(350,161,180,'blocks.common-fields','imageMetadata',1),(351,162,181,'blocks.common-fields','imageMetadata',1),(355,122,184,'blocks.common-fields','imageMetadata',1),(356,163,185,'blocks.common-fields','imageMetadata',1),(357,2,183,'blocks.common-fields','imageMetadata',1),(358,130,186,'blocks.common-fields','imageMetadata',1),(359,83,187,'blocks.common-fields','imageMetadata',1),(360,45,188,'blocks.common-fields','imageMetadata',1),(361,3,4,'blocks.common-fields','imageMetadata',1),(362,4,5,'blocks.common-fields','imageMetadata',1),(363,5,6,'blocks.common-fields','imageMetadata',1),(364,7,8,'blocks.common-fields','imageMetadata',1),(365,8,9,'blocks.common-fields','imageMetadata',1),(366,9,10,'blocks.common-fields','imageMetadata',1),(367,11,12,'blocks.common-fields','imageMetadata',1),(368,12,13,'blocks.common-fields','imageMetadata',1),(369,13,14,'blocks.common-fields','imageMetadata',1),(370,6,7,'blocks.common-fields','imageMetadata',1),(371,10,11,'blocks.common-fields','imageMetadata',1);
/*!40000 ALTER TABLE `medias_components` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-22 19:25:30
