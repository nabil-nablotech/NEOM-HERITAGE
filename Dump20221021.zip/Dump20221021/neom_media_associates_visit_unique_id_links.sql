-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `media_associates_visit_unique_id_links`
--

DROP TABLE IF EXISTS `media_associates_visit_unique_id_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_associates_visit_unique_id_links` (
  `media_associate_id` int unsigned DEFAULT NULL,
  `visit_id` int unsigned DEFAULT NULL,
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `media_associates_visit_unique_id_links_fk` (`media_associate_id`),
  KEY `media_associates_visit_unique_id_links_inv_fk` (`visit_id`),
  CONSTRAINT `media_associates_visit_unique_id_links_fk` FOREIGN KEY (`media_associate_id`) REFERENCES `media_associates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_associates_visit_unique_id_links_inv_fk` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_associates_visit_unique_id_links`
--

LOCK TABLES `media_associates_visit_unique_id_links` WRITE;
/*!40000 ALTER TABLE `media_associates_visit_unique_id_links` DISABLE KEYS */;
INSERT INTO `media_associates_visit_unique_id_links` VALUES (57,1,134),(58,1,135),(59,1,136),(60,1,137),(61,1,138),(62,1,139),(63,1,140),(64,1,141),(65,1,142),(66,1,143),(67,1,144),(68,1,145),(69,1,146),(70,1,147),(71,1,148),(72,1,149),(73,1,150),(74,1,151),(75,1,152),(76,1,153),(77,1,154),(78,1,155),(79,1,156),(82,1,157),(83,1,158),(84,1,159),(85,1,160),(86,1,161),(87,1,162),(88,1,163),(89,1,164),(90,1,165),(91,1,166),(92,1,167),(93,1,168),(94,1,169),(95,1,170),(96,1,171),(97,1,172),(98,1,173),(99,1,174),(10,2,175),(109,2,176),(110,2,177),(134,2,178),(135,2,179),(9,3,180),(111,3,181),(112,3,182),(136,3,183),(137,3,184),(8,4,185),(100,4,186),(101,4,187),(102,4,188),(103,4,189),(113,4,190),(132,4,191),(133,4,192),(138,4,193),(139,4,194),(140,4,195),(141,4,196),(142,4,197),(143,4,198),(144,4,199),(7,5,200),(43,5,201),(44,5,202),(104,5,203),(105,5,204),(114,5,205),(145,5,206),(6,6,207),(41,6,208),(42,6,209),(115,6,210),(116,6,211),(117,6,212),(118,6,213),(119,6,214),(120,6,215),(5,7,216),(32,7,217),(33,7,218),(36,7,219),(37,7,220),(38,7,221),(39,7,222),(40,7,223),(121,7,224),(122,7,225),(123,7,226),(124,7,227),(129,7,228),(130,7,229),(4,8,230),(22,8,231),(23,8,232),(24,8,233),(25,8,234),(26,8,235),(27,8,236),(28,8,237),(29,8,238),(30,8,239),(31,8,240),(106,8,241),(131,8,242),(3,9,243),(20,9,244),(21,9,245),(125,9,246),(126,9,247),(127,9,248),(128,9,249),(2,10,250),(16,10,251),(17,10,252),(18,10,253),(19,10,254),(1,11,255),(11,11,256),(12,11,257),(13,11,258),(14,11,259),(15,11,260),(107,11,261),(108,11,262);
/*!40000 ALTER TABLE `media_associates_visit_unique_id_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-21 16:59:42
