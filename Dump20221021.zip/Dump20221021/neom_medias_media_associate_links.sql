-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: neom
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medias_media_associate_links`
--

DROP TABLE IF EXISTS `medias_media_associate_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medias_media_associate_links` (
  `media_id` int unsigned DEFAULT NULL,
  `media_associate_id` int unsigned DEFAULT NULL,
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `medias_media_associate_links_fk` (`media_id`),
  KEY `medias_media_associate_links_inv_fk` (`media_associate_id`),
  CONSTRAINT `medias_media_associate_links_fk` FOREIGN KEY (`media_id`) REFERENCES `medias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `medias_media_associate_links_inv_fk` FOREIGN KEY (`media_associate_id`) REFERENCES `media_associates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medias_media_associate_links`
--

LOCK TABLES `medias_media_associate_links` WRITE;
/*!40000 ALTER TABLE `medias_media_associate_links` DISABLE KEYS */;
INSERT INTO `medias_media_associate_links` VALUES (140,2,2),(139,3,3),(138,4,4),(137,5,5),(136,6,6),(135,7,7),(134,8,8),(133,9,9),(132,10,10),(131,11,11),(130,12,12),(129,13,13),(128,14,14),(127,15,15),(126,16,16),(125,17,17),(124,18,18),(123,19,19),(122,20,20),(121,21,21),(120,22,22),(119,23,23),(118,24,24),(117,25,25),(116,26,26),(115,27,27),(114,28,28),(113,29,29),(112,30,30),(111,31,31),(110,32,32),(109,33,33),(108,36,36),(107,37,37),(106,38,38),(105,39,39),(104,40,40),(103,41,41),(102,42,42),(101,43,43),(100,44,44),(2,46,46),(3,47,47),(4,48,48),(5,49,49),(6,50,50),(7,51,51),(8,52,52),(9,53,53),(10,54,54),(11,55,55),(12,56,56),(13,57,57),(14,58,58),(15,59,59),(16,60,60),(17,61,61),(18,62,62),(19,63,63),(20,64,64),(21,65,65),(22,66,66),(23,67,67),(24,68,68),(25,69,69),(26,70,70),(27,71,71),(28,72,72),(29,73,73),(30,74,74),(31,75,75),(32,76,76),(33,77,77),(34,78,78),(35,79,79),(36,82,82),(37,83,83),(38,84,84),(39,85,85),(40,86,86),(41,87,87),(42,88,88),(43,89,89),(44,90,90),(45,91,91),(46,92,92),(47,93,93),(48,94,94),(49,95,95),(50,96,96),(51,97,97),(52,98,98),(53,99,99),(54,100,100),(55,101,101),(56,102,102),(57,103,103),(58,104,104),(59,105,105),(60,106,106),(61,107,107),(62,108,108),(63,109,109),(64,110,110),(65,111,111),(66,112,112),(67,113,113),(68,114,114),(69,115,115),(70,116,116),(71,117,117),(72,118,118),(73,119,119),(74,120,120),(75,121,121),(76,122,122),(77,123,123),(78,124,124),(79,125,125),(80,126,126),(81,127,127),(82,128,128),(83,129,129),(84,130,130),(85,131,131),(86,132,132),(87,133,133),(88,134,134),(89,135,135),(90,136,136),(91,137,137),(92,138,138),(93,139,139),(94,140,140),(95,141,141),(96,142,142),(97,143,143),(98,144,144),(99,145,145),(141,1,146),(1,45,147);
/*!40000 ALTER TABLE `medias_media_associate_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-21 16:59:44
